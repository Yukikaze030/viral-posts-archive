/*
 * Copyright 2010-2020 Gildas Lormeau
 * contact : gildas.lormeau <at> gmail.com
 * 
 * This file is part of SingleFile.
 *
 *   The code in this file is free software: you can redistribute it and/or 
 *   modify it under the terms of the GNU Affero General Public License 
 *   (GNU AGPL) as published by the Free Software Foundation, either version 3
 *   of the License, or (at your option) any later version.
 * 
 *   The code in this file is distributed in the hope that it will be useful, 
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero 
 *   General Public License for more details.
 *
 *   As additional permission under GNU AGPL version 3 section 7, you may 
 *   distribute UNMODIFIED VERSIONS OF THIS file without the copy of the GNU 
 *   AGPL normally required by section 4, provided you include this license 
 *   notice and a URL through which recipients can access the Corresponding 
 *   Source.
 */

/* global browser, navigator, btoa */

import { download } from "./download-util.js";
import * as tabsData from "./tabs-data.js";
import * as syncStorage from "./sync-storage.js";
import { normalizeLayout } from "./../../ui/common/menu-layout.js";
import {
	DEFAULT_REPLACED_CHARACTERS as DEFAULT_FILENAME_REPLACED_CHARACTERS,
	DEFAULT_REPLACEMENT_CHARACTERS as DEFAULT_FILENAME_REPLACEMENT_CHARACTERS
} from "./../../ui/common/filename-replacement.js";
import { DEFAULT_MAX_APPENDED_DATA_LENGTH } from "single-file-core/processors/compression/compression-constants.js";

const CURRENT_PROFILE_NAME = "-";
const DEFAULT_PROFILE_NAME = "__Default_Settings__";
const DISABLED_PROFILE_NAME = "__Disabled_Settings__";
const REGEXP_RULE_PREFIX = "regexp:";
const PROFILE_NAME_PREFIX = "profile_";
const EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY = "externalCaptureAllowedExtensionIds";
const EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY = "externalCaptureDeniedExtensionIds";
const MENU_LAYOUT_KEY = "menuLayout";

const BACKGROUND_SAVE_SUPPORTED = !(/Mobile.*Firefox/.test(navigator.userAgent));
const BROWSER_MENUS_API_SUPPORTED = Boolean(browser.contextMenus);
const LEGACY_FILENAME_REPLACED_CHARACTERS = ["~", "+", "\\\\", "?", "%", "*", ":", "|", "\"", "<", ">", "\u0000-\u001f", "\u007f"];

const DEPRECATED_OPTION_NAMES = {
	loadDeferredImages: "loadDeferredContent",
	loadDeferredImagesMaxIdleTime: "loadDeferredContentMaxIdleTime",
	loadDeferredImagesBlockCookies: "loadDeferredContentBlockCookies",
	loadDeferredImagesBlockStorage: "loadDeferredContentBlockStorage",
	loadDeferredImagesKeepZoomLevel: "loadDeferredContentKeepZoomLevel",
	loadDeferredImagesBeforeFrames: "loadDeferredContentBeforeFrames",
	loadDeferredImagesDispatchScrollEvent: null
};

const DEFAULT_CONFIG = {
	removeHiddenElements: true,
	removedElementsSelector: "",
	removeUnusedStyles: true,
	removeUnusedFonts: true,
	removeUnusedGlyphs: false,
	removeFrames: false,
	compressHTML: true,
	loadDeferredContent: true,
	loadDeferredContentMaxIdleTime: 1500,
	loadDeferredContentBlockCookies: false,
	loadDeferredContentBlockStorage: false,
	loadDeferredContentKeepZoomLevel: false,
	loadDeferredContentDispatchScrollEvent: true,
	loadDeferredContentBeforeFrames: false,
	loadDeferredContentMinZoomFactor: 0,
	loadDeferredContentKeepEmulatedScreenSize: false,
	filenameTemplate: "%if-empty<{page-title}|No title> ({date-locale} {time-locale}).{filename-extension}",
	infobarTemplate: "",
	includeInfobar: false,
	openInfobar: false,
	animateInfobar: true,
	confirmInfobarContent: false,
	autoClose: false,
	confirmFilename: false,
	filenameConflictAction: "uniquify",
	filenameMaxLength: 192,
	filenameMaxLengthUnit: "bytes",
	filenameReplacedCharacters: DEFAULT_FILENAME_REPLACED_CHARACTERS,
	filenameReplacementCharacter: "_",
	filenameReplacementCharacters: DEFAULT_FILENAME_REPLACEMENT_CHARACTERS,
	replaceEmojisInFilename: false,
	saveFilenameTemplateData: false,
	contextMenuEnabled: true,
	tabMenuEnabled: true,
	browserActionMenuEnabled: true,
	shadowEnabled: true,
	logsEnabled: true,
	progressBarEnabled: true,
	maxResourceSizeEnabled: false,
	maxResourceSize: 10,
	displayInfobar: true,
	displayStats: false,
	backgroundSave: BACKGROUND_SAVE_SUPPORTED,
	defaultEditorMode: "normal",
	applySystemTheme: true,
	contentWidth: 70,
	autoSaveDelay: 1,
	autoSaveLoad: false,
	autoSaveUnload: false,
	autoSaveLoadOrUnload: true,
	autoSaveDiscard: false,
	autoSaveRemove: false,
	autoSaveRepeat: false,
	autoSaveRepeatDelay: 10,
	removeAlternativeFonts: true,
	removeAlternativeMedias: true,
	removeAlternativeImages: true,
	groupDuplicateImages: true,
	maxSizeDuplicateImages: 512 * 1024,
	saveRawPage: false,
	saveToClipboard: false,
	addProof: false,
	saveToGDrive: false,
	saveToDropbox: false,
	saveWithWebDAV: false,
	webDAVURL: "",
	webDAVUser: "",
	webDAVPassword: "",
	saveWithMCP: false,
	mcpServerUrl: "",
	mcpAuthToken: "",
	saveToGitHub: false,
	saveToRestFormApi: false,
	saveToS3: false,
	githubToken: "",
	githubUser: "",
	githubRepository: "SingleFile-Archives",
	githubBranch: "main",
	saveWithCompanion: false,
	sharePage: false,
	forceWebAuthFlow: true,
	resolveFragmentIdentifierURLs: false,
	userScriptEnabled: false,
	openEditor: false,
	openSavedPage: false,
	autoOpenEditor: false,
	saveCreatedBookmarks: false,
	allowedBookmarkFolders: [],
	ignoredBookmarkFolders: [],
	replaceBookmarkURL: true,
	saveFavicon: true,
	includeBOM: false,
	warnUnsavedPage: true,
	displayInfobarInEditor: false,
	compressContent: false,
	createRootDirectory: false,
	selfExtractingArchive: false,
	disableCompression: false,
	extractDataFromPage: false,
	preventAppendedData: false,
	maxAppendedDataLength: DEFAULT_MAX_APPENDED_DATA_LENGTH,
	insertEmbeddedImage: false,
	insertEmbeddedScreenshotImage: false,
	insertTextBody: false,
	autoSaveExternalSave: false,
	insertMetaNoIndex: false,
	insertMetaCSP: true,
	insertCanonicalLink: true,
	readMaffMetadata: false,
	passReferrerOnError: false,
	password: "",
	insertSingleFileComment: true,
	removeSavedDate: false,
	blockMixedContent: false,
	saveOriginalURLs: false,
	acceptHeaders: {
		font: "application/font-woff2;q=1.0,application/font-woff;q=0.9,*/*;q=0.8",
		image: "image/jxl,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
		stylesheet: "text/css,*/*;q=0.1",
		script: "*/*",
		document: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		video: "video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5",
		audio: "audio/webm,audio/ogg,audio/wav,audio/*;q=0.9,application/ogg;q=0.7,video/*;q=0.6,*/*;q=0.5"
	},
	moveStylesInHead: false,
	customStylesheet: "",
	embeddedScript: "",
	networkTimeout: 0,
	woleetKey: "",
	blockImages: false,
	blockStylesheets: false,
	blockFonts: false,
	blockScripts: true,
	blockVideos: true,
	blockAudios: true,
	delayBeforeProcessing: 0,
	delayAfterProcessing: 0,
	_migratedTemplateFormat: true,
	_migratedDeferredContentOptions: true,
	saveToRestFormApiUrl: "",
	saveToRestFormApiFileFieldName: "",
	saveToRestFormApiUrlFieldName: "",
	saveToRestFormApiToken: "",
	S3Domain: "s3.amazonaws.com",
	S3Region: "",
	S3Bucket: "",
	S3AccessKey: "",
	S3SecretKey: "",
	resolveLinks: true,
	groupDuplicateStylesheets: false,
	infobarPositionAbsolute: false,
	infobarPositionTop: "16px",
	infobarPositionRight: "16px",
	infobarPositionBottom: "",
	infobarPositionLeft: "",
	removeNoScriptTags: true,
	customShortcut: null,
	imageReductionFactor: 1,
	imageQuality: 0.8
};

const DEFAULT_RULES = [{
	"url": "file:",
	"profile": "__Default_Settings__",
	"autoSaveProfile": "__Disabled_Settings__"
}];

const MIGRATION_DEFAULT_VARIABLES_VALUES = {
	"page-title": "No title",
	"page-heading": "No heading",
	"page-language": "No language",
	"page-description": "No description",
	"page-author": "No author",
	"page-creator": "No creator",
	"page-publisher": "No publisher",
	"url-hash": "No hash",
	"url-host": "No host",
	"url-hostname": "No hostname",
	"url-href": "No href",
	"url-href-digest-sha-1": "No hash",
	"url-href-flat": "No href",
	"url-referrer": "No referrer",
	"url-referrer-flat": "No referrer",
	"url-password": "No password",
	"url-pathname": "No pathname",
	"url-pathname-flat": "No pathname",
	"url-port": "No port",
	"url-protocol": "No protocol",
	"url-search": "No search",
	"url-username": "No username",
	"tab-id": "No tab id",
	"tab-index": "No tab index",
	"url-last-segment": "No last segment"
};

let configStorage;
let pendingUpgradePromise = upgrade();
export {
	DEFAULT_PROFILE_NAME,
	DISABLED_PROFILE_NAME,
	CURRENT_PROFILE_NAME,
	PROFILE_NAME_PREFIX,
	MENU_LAYOUT_KEY,
	BACKGROUND_SAVE_SUPPORTED,
	BROWSER_MENUS_API_SUPPORTED,
	getConfig as get,
	getRule,
	getOptions,
	getProfileOptions,
	getMenuLayout,
	getExternalCapturePermissions,
	setExternalCapturePermissions,
	getProfiles,
	onMessage,
	updateRule,
	addRule,
	getAuthInfo,
	getDropboxAuthInfo,
	setAuthInfo,
	setDropboxAuthInfo,
	removeAuthInfo,
	removeDropboxAuthInfo
};

async function upgrade() {
	const { sync } = await browser.storage.local.get();
	if (sync) {
		configStorage = syncStorage;
	} else {
		configStorage = browser.storage.local;
	}
	const config = await configStorage.get();
	if (!config[PROFILE_NAME_PREFIX + DEFAULT_PROFILE_NAME]) {
		if (config.profiles) {
			const profileNames = Object.keys(config.profiles);
			for (const profileName of profileNames) {
				await setProfile(profileName, config.profiles[profileName]);
			}
		} else {
			await setProfile(DEFAULT_PROFILE_NAME, DEFAULT_CONFIG);
		}
	} else if (config.profiles) {
		await configStorage.remove(["profiles"]);
	}
	if (!config.rules) {
		await configStorage.set({ rules: DEFAULT_RULES });
	}
	if (!config.maxParallelWorkers) {
		await configStorage.set({ maxParallelWorkers: navigator.hardwareConcurrency || 4 });
	}
	if (!config.processInForeground) {
		await configStorage.set({ processInForeground: false });
	}
	if (!Array.isArray(config[EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY])) {
		await configStorage.set({ [EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY]: [] });
	}
	if (!Array.isArray(config[EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY])) {
		await configStorage.set({ [EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY]: [] });
	}
	const profileNames = await readProfileNames();
	profileNames.map(async profileName => {
		const profile = await getProfile(profileName);
		if (!profile._migratedTemplateFormat) {
			profile.filenameTemplate = updateFilenameTemplate(profile.filenameTemplate);
			profile._migratedTemplateFormat = true;
		}
		if (!profile._migratedDeferredContentOptions) {
			Object.keys(DEPRECATED_OPTION_NAMES).forEach(deprecatedName => {
				const optionName = DEPRECATED_OPTION_NAMES[deprecatedName];
				if (profile[deprecatedName] !== undefined) {
					if (optionName && profile[optionName] === undefined) {
						profile[optionName] = profile[deprecatedName];
					}
					delete profile[deprecatedName];
				}
			});
			profile._migratedDeferredContentOptions = true;
		}
		delete profile.blockAlternativeImages;
		for (const key of Object.keys(DEFAULT_CONFIG)) {
			if (profile[key] === undefined) {
				profile[key] = DEFAULT_CONFIG[key];
			}
		}
		if (isSameArray(profile.filenameReplacedCharacters, LEGACY_FILENAME_REPLACED_CHARACTERS)
			&& isSameArray(profile.filenameReplacementCharacters, DEFAULT_FILENAME_REPLACEMENT_CHARACTERS)) {
			profile.filenameReplacedCharacters = DEFAULT_FILENAME_REPLACED_CHARACTERS;
		}
		await setProfile(profileName, profile);
	});
}

function updateFilenameTemplate(template) {
	try {
		Object.keys(MIGRATION_DEFAULT_VARIABLES_VALUES).forEach(variable => {
			const value = MIGRATION_DEFAULT_VARIABLES_VALUES[variable];
			template = template.replaceAll(`{${variable}}`, `%if-empty<{${variable}}|${value}>`);
		});
		return template;
		// eslint-disable-next-line no-unused-vars
	} catch (error) {
		// ignored
	}
}

async function getRule(url, ignoreWildcard) {
	await pendingUpgradePromise;
	const { rules } = await configStorage.get(["rules"]);
	const regExpRules = rules.filter(rule => testRegExpRule(rule));
	let rule = regExpRules.sort(sortRules).find(rule => url && url.match(new RegExp(rule.url.split(REGEXP_RULE_PREFIX)[1])));
	if (!rule) {
		const normalRules = rules.filter(rule => !testRegExpRule(rule));
		rule = normalRules.sort(sortRules).find(rule => (!ignoreWildcard && rule.url == "*") || (url && url.includes(rule.url)));
	}
	return rule;
}

async function getConfig() {
	await pendingUpgradePromise;
	const { maxParallelWorkers, processInForeground } = await configStorage.get(["maxParallelWorkers", "processInForeground"]);
	const rules = await getRules();
	const profiles = await getProfiles();
	const menuLayout = await getMenuLayout();
	const config = { profiles, rules, maxParallelWorkers, processInForeground };
	if (menuLayout) {
		config.menuLayout = menuLayout;
	}
	return config;
}

async function getMenuLayout() {
	await pendingUpgradePromise;
	const data = await configStorage.get([MENU_LAYOUT_KEY]);
	return normalizeLayout(data[MENU_LAYOUT_KEY]);
}

async function setMenuLayout(menuLayout) {
	await pendingUpgradePromise;
	const layout = normalizeLayout(menuLayout);
	if (layout) {
		await configStorage.set({ [MENU_LAYOUT_KEY]: layout });
	} else {
		await configStorage.remove([MENU_LAYOUT_KEY]);
	}
}

async function updateMenuLayoutProfile(profileName, newProfileName) {
	const menuLayout = await getMenuLayout();
	if (menuLayout) {
		const updateEntries = entries => entries.forEach(entry => {
			if (entry.profile == profileName) {
				if (newProfileName) {
					entry.profile = newProfileName;
				} else {
					delete entry.profile;
				}
			}
			if (entry.children) {
				updateEntries(entry.children);
			}
		});
		Object.keys(menuLayout).forEach(surface => updateEntries(menuLayout[surface]));
		await setMenuLayout(menuLayout);
	}
}

async function getExternalCapturePermissions() {
	await pendingUpgradePromise;
	const {
		externalCaptureAllowedExtensionIds = [],
		externalCaptureDeniedExtensionIds = []
	} = await configStorage.get([EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY, EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY]);
	const allowedExtensions = sanitizeExtensionEntries(externalCaptureAllowedExtensionIds);
	const deniedExtensions = sanitizeExtensionEntries(externalCaptureDeniedExtensionIds);
	return {
		allowedExtensions,
		allowedExtensionIds: allowedExtensions.map(entry => entry.id),
		deniedExtensions,
		deniedExtensionIds: deniedExtensions.map(entry => entry.id)
	};
}

async function setExternalCapturePermissions({ allowedExtensions, deniedExtensions } = {}) {
	await pendingUpgradePromise;
	const permissions = {};
	if (allowedExtensions !== undefined) {
		permissions[EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY] = sanitizeExtensionEntries(allowedExtensions);
	}
	if (deniedExtensions !== undefined) {
		permissions[EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY] = sanitizeExtensionEntries(deniedExtensions);
	}
	await configStorage.set(permissions);
}

function sanitizeExtensionEntries(extensionEntries) {
	const knownIds = new Set();
	return (extensionEntries || []).map(extensionEntry => {
		if (typeof extensionEntry == "string") {
			return { id: extensionEntry.trim(), name: "" };
		}
		return {
			id: String(extensionEntry.id || "").trim(),
			name: String(extensionEntry.name || "").trim().replace(/\s+/g, " ").slice(0, 80)
		};
	}).filter(extensionEntry => {
		if (!extensionEntry.id || knownIds.has(extensionEntry.id)) {
			return false;
		}
		knownIds.add(extensionEntry.id);
		return true;
	});
}

function sortRules(ruleLeft, ruleRight) {
	return ruleRight.url.length - ruleLeft.url.length;
}

function testRegExpRule(rule) {
	return rule.url.toLowerCase().startsWith(REGEXP_RULE_PREFIX);
}

async function onMessage(message) {
	if (message.method.endsWith(".get")) {
		return await getConfig();
	}
	if (message.method.endsWith(".set")) {
		const { config } = message;
		const profiles = config.profiles;
		const rules = config.rules;
		const maxParallelWorkers = config.maxParallelWorkers;
		const processInForeground = config.processInForeground;
		const profileKeyNames = await getProfileKeyNames();
		await configStorage.remove([...profileKeyNames, "rules", "maxParallelWorkers", "processInForeground", MENU_LAYOUT_KEY]);
		await configStorage.set({ rules, maxParallelWorkers, processInForeground });
		await setMenuLayout(config.menuLayout);
		Object.keys(profiles).forEach(profileName => setProfile(profileName, profiles[profileName]));
	}
	if (message.method.endsWith(".getMenuLayout")) {
		return { menuLayout: await getMenuLayout() };
	}
	if (message.method.endsWith(".setMenuLayout")) {
		await setMenuLayout(message.menuLayout);
	}
	if (message.method.endsWith(".deleteRules")) {
		await deleteRules(message.profileName);
	}
	if (message.method.endsWith(".deleteRule")) {
		await deleteRule(message.url);
	}
	if (message.method.endsWith(".addRule")) {
		await addRule(message.url, message.profileName, message.autoSaveProfileName);
	}
	if (message.method.endsWith(".createProfile")) {
		await createProfile(message.profileName, message.fromProfileName || DEFAULT_PROFILE_NAME);
	}
	if (message.method.endsWith(".renameProfile")) {
		await renameProfile(message.profileName, message.newProfileName);
	}
	if (message.method.endsWith(".deleteProfile")) {
		await deleteProfile(message.profileName);
	}
	if (message.method.endsWith(".resetProfiles")) {
		await resetProfiles();
	}
	if (message.method.endsWith(".resetProfile")) {
		await resetProfile(message.profileName);
	}
	if (message.method.endsWith(".importConfig")) {
		await importConfig(message.config);
	}
	if (message.method.endsWith(".updateProfile")) {
		await updateProfile(message.profileName, message.profile);
	}
	if (message.method.endsWith(".updateRule")) {
		await updateRule(message.url, message.newUrl, message.profileName, message.autoSaveProfileName);
	}
	if (message.method.endsWith(".getConstants")) {
		return {
			DISABLED_PROFILE_NAME,
			DEFAULT_PROFILE_NAME,
			CURRENT_PROFILE_NAME,
			BACKGROUND_SAVE_SUPPORTED,
			BROWSER_MENUS_API_SUPPORTED,
			DEFAULT_FILENAME_REPLACED_CHARACTERS,
			DEFAULT_FILENAME_REPLACEMENT_CHARACTERS
		};
	}
	if (message.method.endsWith(".getRules")) {
		return getRules();
	}
	if (message.method.endsWith(".getProfileOptions")) {
		return getProfileOptions(message.profileName);
	}
	if (message.method.endsWith(".getProfileName")) {
		return getProfileName(message.url);
	}
	if (message.method.endsWith(".getProfiles")) {
		return getProfiles();
	}
	if (message.method.endsWith(".exportConfig")) {
		return exportConfig();
	}
	if (message.method.endsWith(".enableSync")) {
		const syncConfig = await syncStorage.get();
		if (!syncConfig || !syncConfig.rules) {
			const profileKeyNames = await getProfileKeyNames();
			const localConfig = await browser.storage.local.get(["rules", "maxParallelWorkers", "processInForeground", EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY, EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY, MENU_LAYOUT_KEY, ...profileKeyNames]);
			await syncStorage.set(localConfig);
		}
		await browser.storage.local.set({ sync: true });
		configStorage = syncStorage;
		await upgrade();
		return {};
	}
	if (message.method.endsWith(".disableSync")) {
		await browser.storage.local.set({ sync: false });
		const syncConfig = await syncStorage.get();
		const localConfig = await browser.storage.local.get();
		if (syncConfig && syncConfig.rules && (!localConfig || !localConfig.rules)) {
			await browser.storage.local.set({
				rules: syncConfig.rules,
				maxParallelWorkers: syncConfig.maxParallelWorkers,
				processInForeground: syncConfig.processInForeground,
				externalCaptureAllowedExtensionIds: syncConfig.externalCaptureAllowedExtensionIds || [],
				externalCaptureDeniedExtensionIds: syncConfig.externalCaptureDeniedExtensionIds || []
			});
			if (syncConfig[MENU_LAYOUT_KEY]) {
				await browser.storage.local.set({ [MENU_LAYOUT_KEY]: syncConfig[MENU_LAYOUT_KEY] });
			}
			const profiles = {};
			Object.keys(syncConfig)
				.filter(keyName => keyName.startsWith(PROFILE_NAME_PREFIX))
				.forEach(keyName => profiles[keyName] = syncConfig[keyName]);
			await browser.storage.local.set(profiles);
		}
		configStorage = browser.storage.local;
		await upgrade();
		return {};
	}
	if (message.method.endsWith(".isSync")) {
		return { sync: (await browser.storage.local.get()).sync };
	}
	return {};
}

async function createProfile(profileName, fromProfileName) {
	const profileNames = await getProfileNames();
	if (profileNames.includes(profileName)) {
		throw new Error("Duplicate profile name");
	}
	const profileFrom = await getProfile(fromProfileName);
	const profile = JSON.parse(JSON.stringify(profileFrom));
	profile.customShortcut = null;
	await setProfile(profileName, profile);
}

async function getProfiles() {
	await pendingUpgradePromise;
	const profileKeyNames = await getProfileKeyNames();
	const profiles = await configStorage.get(profileKeyNames);
	const result = {};
	Object.keys(profiles).forEach(profileName => result[profileName.substring(PROFILE_NAME_PREFIX.length)] = profiles[profileName]);
	return result;
}

async function getOptions(url, autoSave) {
	return getProfileOptions(await getProfileName(url, autoSave));
}

async function getProfileName(url, autoSave) {
	await pendingUpgradePromise;
	const [rule, allTabsData] = await Promise.all([getRule(url), tabsData.get()]);
	const tabProfileName = allTabsData.profileName || DEFAULT_PROFILE_NAME;
	if (rule) {
		const profileName = rule[autoSave ? "autoSaveProfile" : "profile"];
		return profileName == CURRENT_PROFILE_NAME ? tabProfileName : profileName;
	} else {
		return tabProfileName;
	}
}

async function getProfileOptions(profileName) {
	const options = Object.assign({ profileName }, await getProfile(profileName));
	if (!BACKGROUND_SAVE_SUPPORTED) {
		options.backgroundSave = false;
	}
	return options;
}

async function updateProfile(profileName, profile) {
	const profileNames = await getProfileNames();
	if (!profileNames.includes(profileName)) {
		throw new Error("Profile not found");
	}
	const previousProfile = await getProfile(profileName);
	Object.keys(previousProfile).forEach(key => {
		profile[key] = profile[key] === undefined ? previousProfile[key] : profile[key];
	});
	await setProfile(profileName, profile);
}

async function renameProfile(oldProfileName, profileName) {
	const profileNames = await getProfileNames();
	const allTabsData = await tabsData.get();
	const rules = await getRules();
	if (!profileNames.includes(oldProfileName)) {
		throw new Error("Profile not found");
	}
	if (profileNames.includes(profileName)) {
		throw new Error("Duplicate profile name");
	}
	if (oldProfileName == DEFAULT_PROFILE_NAME) {
		throw new Error("Default settings cannot be renamed");
	}
	if (allTabsData.profileName == oldProfileName) {
		allTabsData.profileName = profileName;
		await tabsData.set(allTabsData);
	}
	rules.forEach(rule => {
		if (rule.profile == oldProfileName) {
			rule.profile = profileName;
		}
		if (rule.autoSaveProfile == oldProfileName) {
			rule.autoSaveProfile = profileName;
		}
	});
	const profile = await getProfile(oldProfileName);
	await configStorage.remove([PROFILE_NAME_PREFIX + oldProfileName]);
	await configStorage.set({ [PROFILE_NAME_PREFIX + profileName]: profile, rules });
	await updateMenuLayoutProfile(oldProfileName, profileName);
}

async function deleteProfile(profileName) {
	const profileNames = await getProfileNames();
	const allTabsData = await tabsData.get();
	const rules = await getRules();
	if (!profileNames.includes(profileName)) {
		throw new Error("Profile not found");
	}
	if (profileName == DEFAULT_PROFILE_NAME) {
		throw new Error("Default settings cannot be deleted");
	}
	if (allTabsData.profileName == profileName) {
		delete allTabsData.profileName;
		await tabsData.set(allTabsData);
	}
	rules.forEach(rule => {
		if (rule.profile == profileName) {
			rule.profile = DEFAULT_PROFILE_NAME;
		}
		if (rule.autoSaveProfile == profileName) {
			rule.autoSaveProfile = DEFAULT_PROFILE_NAME;
		}
	});
	configStorage.remove([PROFILE_NAME_PREFIX + profileName]);
	await configStorage.set({ rules });
	await updateMenuLayoutProfile(profileName);
}

async function getRules() {
	await pendingUpgradePromise;
	return (await configStorage.get(["rules"])).rules;
}

async function getProfileNames() {
	await pendingUpgradePromise;
	return readProfileNames();
}

async function readProfileNames() {
	return Object.keys(await configStorage.get()).filter(key => key.startsWith(PROFILE_NAME_PREFIX)).map(key => key.substring(PROFILE_NAME_PREFIX.length));
}

async function getProfileKeyNames() {
	await pendingUpgradePromise;
	return Object.keys(await configStorage.get()).filter(key => key.startsWith(PROFILE_NAME_PREFIX));
}

async function getProfile(profileName) {
	const profileKey = PROFILE_NAME_PREFIX + profileName;
	const data = await configStorage.get([profileKey]);
	return data[profileKey];
}

async function setProfile(profileName, profileData) {
	const profileKey = PROFILE_NAME_PREFIX + profileName;
	await configStorage.set({ [profileKey]: profileData });
}

async function addRule(url, profile, autoSaveProfile) {
	if (!url) {
		throw new Error("URL is empty");
	}
	const rules = await getRules();
	if (rules.find(rule => rule.url == url)) {
		throw new Error("URL already exists");
	}
	rules.push({
		url,
		profile,
		autoSaveProfile
	});
	await configStorage.set({ rules });
}

async function deleteRule(url) {
	if (!url) {
		throw new Error("URL is empty");
	}
	const rules = await getRules();
	await configStorage.set({ rules: rules.filter(rule => rule.url != url) });
}

async function deleteRules(profileName) {
	const rules = await getRules();
	await configStorage.set({ rules: profileName ? rules.filter(rule => rule.autoSaveProfile != profileName && rule.profile != profileName) : [] });
}

async function updateRule(url, newURL, profile, autoSaveProfile) {
	if (!url || !newURL) {
		throw new Error("URL is empty");
	}
	const rules = await getRules();
	const urlConfig = rules.find(rule => rule.url == url);
	if (!urlConfig) {
		throw new Error("URL not found");
	}
	if (rules.find(rule => rule.url == newURL && rule.url != url)) {
		throw new Error("New URL already exists");
	}
	urlConfig.url = newURL;
	urlConfig.profile = profile;
	urlConfig.autoSaveProfile = autoSaveProfile;
	await configStorage.set({ rules });
}

async function getAuthInfo() {
	await pendingUpgradePromise;
	return (await configStorage.get()).authInfo;
}

async function getDropboxAuthInfo() {
	await pendingUpgradePromise;
	return (await configStorage.get()).dropboxAuthInfo;
}

async function setAuthInfo(authInfo) {
	await configStorage.set({ authInfo });
}

async function setDropboxAuthInfo(authInfo) {
	await configStorage.set({ dropboxAuthInfo: authInfo });
}

async function removeAuthInfo() {
	const authInfo = await getAuthInfo();
	if (authInfo && authInfo.revokableAccessToken) {
		await setAuthInfo({ revokableAccessToken: authInfo.revokableAccessToken });
	} else {
		await configStorage.remove(["authInfo"]);
	}
}

async function removeDropboxAuthInfo() {
	const authInfo = await getDropboxAuthInfo();
	if (authInfo && authInfo.revokableAccessToken) {
		await setDropboxAuthInfo({ revokableAccessToken: authInfo.revokableAccessToken });
	} else {
		await configStorage.remove(["dropboxAuthInfo"]);
	}
}

async function resetProfiles() {
	await pendingUpgradePromise;
	const allTabsData = await tabsData.get();
	delete allTabsData.profileName;
	await tabsData.set(allTabsData);
	let profileKeyNames = await getProfileKeyNames();
	await configStorage.remove([...profileKeyNames, "rules", "maxParallelWorkers", "processInForeground", EXTERNAL_CAPTURE_ALLOWED_EXTENSION_IDS_KEY, EXTERNAL_CAPTURE_DENIED_EXTENSION_IDS_KEY, MENU_LAYOUT_KEY]);
	await upgrade();
}

async function resetProfile(profileName) {
	const profileNames = await getProfileNames();
	if (!profileNames.includes(profileName)) {
		throw new Error("Profile not found");
	}
	await setProfile(profileName, DEFAULT_CONFIG);
}

async function exportConfig() {
	const config = await getConfig();
	const exportedConfig = { profiles: config.profiles, rules: config.rules, maxParallelWorkers: config.maxParallelWorkers, processInForeground: config.processInForeground };
	if (config.menuLayout) {
		exportedConfig.menuLayout = config.menuLayout;
	}
	const textContent = JSON.stringify(exportedConfig, null, 2);
	const filename = `singlefile-settings-${(new Date()).toISOString().replace(/:/g, "_")}.json`;
	const url = "data:text/json;base64," + btoa(unescape(encodeURIComponent(textContent)));
	const downloadInfo = {
		url,
		filename,
		saveAs: true
	};
	await download(downloadInfo, "_");
}

async function importConfig(config) {
	const profileNames = await getProfileNames();
	const profileKeyNames = await getProfileKeyNames();
	const allTabsData = await tabsData.get();
	if (profileNames.includes(allTabsData.profileName)) {
		delete allTabsData.profileName;
		await tabsData.set(allTabsData);
	}
	const newConfig = { rules: config.rules, maxParallelWorkers: config.maxParallelWorkers, processInForeground: config.processInForeground };
	const menuLayout = normalizeLayout(config.menuLayout);
	if (menuLayout) {
		newConfig[MENU_LAYOUT_KEY] = menuLayout;
	}
	Object.keys(config.profiles).forEach(profileName => newConfig[PROFILE_NAME_PREFIX + profileName] = config.profiles[profileName]);
	await configStorage.set(newConfig);
	const staleKeys = [...profileKeyNames, MENU_LAYOUT_KEY].filter(key => !(key in newConfig));
	if (staleKeys.length) {
		await configStorage.remove(staleKeys);
	}
	await upgrade();
}

function isSameArray(arrayLeft, arrayRight) {
	return arrayLeft.length == arrayRight.length && arrayLeft.every((value, index) => value == arrayRight[index]);
}
