/*
 * Copyright 2010-2020 Gildas Lormeau
 * contact : gildas.lormeau <at> gmail.com
 * 
 * This file is part of SingleFile.
 *
 *   The code in this file is free software: you can redistribute it and/or 
 *   modify it under the terms of the GNU Affero General Public License 
 *   (GNU AGPL) as published by the Free Software Foundation, either version 3
 *   of the License, or (at your option) any later version.
 * 
 *   The code in this file is distributed in the hope that it will be useful, 
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero 
 *   General Public License for more details.
 *
 *   As additional permission under GNU AGPL version 3 section 7, you may 
 *   distribute UNMODIFIED VERSIONS OF THIS file without the copy of the GNU 
 *   AGPL normally required by section 4, provided you include this license 
 *   notice and a URL through which recipients can access the Corresponding 
 *   Source.
 */

/* global window, document, fetch, DOMParser, NodeFilter, Readability, isProbablyReaderable, matchMedia, TextDecoder, Node, prompt, MutationObserver, btoa */

import { setLabels } from "./../../ui/common/common-content-ui.js";
import { downloadPageForeground } from "../../core/common/download.js";
import { convert } from "../../lib/mhtml-to-html/mod.js";

(() => {

	const singlefile = globalThis.singlefile;
	const { NOTE_TAGNAME, MASK_CLASS, HIGHLIGHT_CLASS, HIGHLIGHT_HIDDEN_CLASS, REMOVED_CONTENT_CLASS, SHADOWROOT_ATTRIBUTE_NAME, SCRIPT_TEMPLATE_SHADOW_ROOT } = singlefile.helper.notes;

	const SCRIPT_OPTIONS = "data-single-file-options";
	const RESERVED_FILES_PREFIX = "sfz-";
	const PAGES_FILENAME = "sfz-pages.json";
	const TOC_FILENAME = "sfz-toc.html";
	const PAGES_PREFIX = "pages/";
	const INDEX_FILENAME = "index.html";
	const MODIFIED_PAGE_CLASS = "sfz-modified-page";
	const MODIFIED_PAGE_STYLE = "." + MODIFIED_PAGE_CLASS + "::after{content:\" \\25CF\";font-size:.75em;opacity:.7}";
	const CUT_HOVER_CLASS = "single-file-cut-hover";
	const CUT_OUTER_HOVER_CLASS = "single-file-cut-outer-hover";
	const CUT_SELECTED_CLASS = "single-file-cut-selected";
	const CUT_OUTER_SELECTED_CLASS = "single-file-cut-outer-selected";
	const CUT_MODE_CLASS = "single-file-cut-mode";
	const DISABLED_NOSCRIPT_ATTRIBUTE_NAME = "data-single-file-disabled-noscript";
	const COMMENT_HEADER = "Page saved with SingleFile";
	const COMMENT_HEADER_LEGACY = "Archive processed by SingleFile";
	const EDIT_MESSAGE_METHODS = ["addNote", "displayNotes", "hideNotes", "enableHighlight", "disableHighlight", "displayHighlights", "hideHighlights", "enableRemoveHighlights", "disableRemoveHighlights", "enableEditPage", "disableEditPage", "formatPage", "cancelFormatPage", "enableCutInnerPage", "enableCutOuterPage", "disableCutInnerPage", "disableCutOuterPage", "undoCutPage", "undoAllCutPage", "redoCutPage"];

	let NOTES_SCRIPT, notes;
	let highlightSelectionMode, removeHighlightMode, highlightColor, cuttingOuterMode, cuttingMode, cuttingTouchTarget, cuttingPath, cuttingPathIndex, previousContent;
	let removedElements = [], removedElementIndex = 0, pageResources, pageUrl, pageCompressContent, includeInfobar, openInfobar, animateInfobar, infobarPositionAbsolute, infobarPositionTop, infobarPositionBottom, infobarPositionLeft, infobarPositionRight;
	let pageArchiveContent, archivePages, archiveManifest, archivePassword, archiveUrlToPath, archiveTocContent, archiveTocPresent, stashedArchivePages, modifiedArchivePagePaths, currentArchivePagePath, archiveTocDisplayed, droppedArchiveContent;

	globalThis.zip = singlefile.helper.zip;
	initEventListeners();
	new MutationObserver(initEventListeners).observe(document, { childList: true });

	function initEventListeners() {
		window.onmessage = async event => {
			const message = JSON.parse(event.data);
			if (message.method == "init") {
				await init(message);
			}
			if (message.method == "displayArchivePage") {
				await openArchivePage(message.pagePath);
			}
			if (message.method == "displayArchiveToc") {
				await displayArchiveToc();
			}
			if (message.method == "archiveSaved") {
				modifiedArchivePagePaths.clear();
				if (archiveTocDisplayed) {
					await displayArchiveToc();
				}
				onUpdate(true);
			}
			if (archiveTocDisplayed && EDIT_MESSAGE_METHODS.includes(message.method)) {
				return;
			}
			if (message.method == "addNote") {
				notes.addNote(message);
			}
			if (message.method == "displayNotes") {
				notes.displayNotes();
			}
			if (message.method == "hideNotes") {
				notes.hideNotes();
			}
			if (message.method == "enableHighlight") {
				if (highlightColor) {
					document.documentElement.classList.remove(highlightColor + "-mode");
				}
				highlightColor = message.color;
				highlightSelectionMode = true;
				document.documentElement.classList.add(message.color + "-mode");
			}
			if (message.method == "disableHighlight") {
				disableHighlight();
				highlightSelectionMode = false;
			}
			if (message.method == "displayHighlights") {
				document.querySelectorAll("." + HIGHLIGHT_CLASS).forEach(noteElement => noteElement.classList.remove(HIGHLIGHT_HIDDEN_CLASS));
			}
			if (message.method == "hideHighlights") {
				document.querySelectorAll("." + HIGHLIGHT_CLASS).forEach(noteElement => noteElement.classList.add(HIGHLIGHT_HIDDEN_CLASS));
			}
			if (message.method == "enableRemoveHighlights") {
				removeHighlightMode = true;
				document.documentElement.classList.add("single-file-remove-highlights-mode");
			}
			if (message.method == "disableRemoveHighlights") {
				removeHighlightMode = false;
				document.documentElement.classList.remove("single-file-remove-highlights-mode");
			}
			if (message.method == "enableEditPage") {
				document.body.contentEditable = true;
				onUpdate(false);
			}
			if (message.method == "formatPage") {
				formatPage(!message.applySystemTheme, message.contentWidth);
			}
			if (message.method == "cancelFormatPage") {
				cancelFormatPage();
			}
			if (message.method == "disableEditPage") {
				document.body.contentEditable = false;
			}
			if (message.method == "enableCutInnerPage") {
				cuttingMode = true;
				document.documentElement.classList.add(CUT_MODE_CLASS);
			}
			if (message.method == "enableCutOuterPage") {
				cuttingOuterMode = true;
				document.documentElement.classList.add(CUT_MODE_CLASS);
			}
			if (message.method == "disableCutInnerPage" || message.method == "disableCutOuterPage") {
				if (message.method == "disableCutInnerPage") {
					cuttingMode = false;
				} else {
					cuttingOuterMode = false;
				}
				document.documentElement.classList.remove(CUT_MODE_CLASS);
				resetSelectedElements();
				if (cuttingPath) {
					unhighlightCutElement();
					cuttingPath = null;
				}
			}
			if (message.method == "undoCutPage") {
				undoCutPage();
			}
			if (message.method == "undoAllCutPage") {
				while (removedElementIndex) {
					removedElements[removedElementIndex - 1].forEach(element => element.classList.remove(REMOVED_CONTENT_CLASS));
					removedElementIndex--;
				}
			}
			if (message.method == "redoCutPage") {
				redoCutPage();
			}
			if (message.method == "getContent") {
				includeInfobar = message.includeInfobar;
				openInfobar = message.openInfobar;
				animateInfobar = message.animateInfobar;
				infobarPositionAbsolute = message.infobarPositionAbsolute;
				infobarPositionTop = message.infobarPositionTop;
				infobarPositionBottom = message.infobarPositionBottom;
				infobarPositionLeft = message.infobarPositionLeft;
				infobarPositionRight = message.infobarPositionRight;
				if (archivePages) {
					await sendArchiveContent(message);
					return;
				}
				onUpdate(true);
				let content = getContent(message.compressHTML);
				let filename;
				const pageOptions = loadOptionsFromPage(document);
				if (pageOptions) {
					pageOptions.backgroundSave = message.backgroundSave;
					pageOptions.saveDate = new Date(pageOptions.saveDate);
					pageOptions.visitDate = new Date(pageOptions.visitDate);
					filename = await singlefile.helper.formatFilename(content, document, pageOptions);
				}
				if (message.sharePage) {
					setLabels(message.labels);
				}
				if (pageCompressContent) {
					const viewport = document.head.querySelector("meta[name=viewport]");
					window.parent.postMessage(JSON.stringify({
						method: "setContent",
						content,
						filename,
						title: document.title,
						doctype: singlefile.helper.getDoctypeString(document),
						url: pageUrl,
						viewport: viewport ? viewport.content : null,
						compressContent: true,
						archiveContent: droppedArchiveContent,
						foregroundSave: message.foregroundSave,
						sharePage: message.sharePage,
						documentHeight: document.documentElement.offsetHeight
					}), "*");
				} else {
					if (message.foregroundSave || message.sharePage) {
						try {
							await downloadPageForeground({
								content,
								filename: filename || message.filename,
								mimeType: "text/html"
							}, { sharePage: message.sharePage });
						} catch (error) {
							console.log(error); // eslint-disable-line no-console
							window.parent.postMessage(JSON.stringify({ method: "onError", error: error.message }), "*");
						}
					} else {
						window.parent.postMessage(JSON.stringify({
							method: "setContent",
							content,
							filename,
							title: document.title,
							url: pageUrl
						}), "*");
					}
				}
			}
			if (message.method == "printPage") {
				printPage();
			}
			if (message.method == "importMht") {
				let { content, filename } = message;
				const { data } = await convert(content, { DOMParser: globalThis.DOMParser });
				content = data;
				await init({ content }, { filename, reset: true, isMHTML: true });
			}
			if (message.method == "displayInfobar") {
				singlefile.helper.displayIcon(document, true, {
					openInfobar: message.openInfobar,
					animateInfobar: message.animateInfobar,
					infobarPositionAbsolute: message.infobarPositionAbsolute,
					infobarPositionTop: message.infobarPositionTop,
					infobarPositionBottom: message.infobarPositionBottom,
					infobarPositionLeft: message.infobarPositionLeft,
					infobarPositionRight: message.infobarPositionRight
				});
				const infobarDoc = document.implementation.createHTMLDocument();
				infobarDoc.body.appendChild(document.querySelector(singlefile.helper.INFOBAR_TAGNAME));
				serializeShadowRoots(infobarDoc.body);
				const content = singlefile.helper.serialize(infobarDoc, true);
				window.parent.postMessage(JSON.stringify({
					method: "displayInfobar",
					content
				}), "*");
			}
			if (message.method == "download") {
				try {
					await downloadPageForeground({
						content: message.content,
						filename: message.filename,
						mimeType: message.mimeType
					}, { sharePage: message.sharePage });
				} catch (error) {
					console.log(error); // eslint-disable-line no-console
					window.parent.postMessage(JSON.stringify({ method: "onError", error: error.message }), "*");
				}
			}
		};
		window.onresize = () => {
			if (notes) {
				notes.reflowNotes();
			}
		};
		document.ondragover = event => event.preventDefault();
		document.ondrop = async event => {
			if (event.dataTransfer.files && event.dataTransfer.files[0]) {
				const file = event.dataTransfer.files[0];
				event.preventDefault();
				let content = new TextDecoder().decode(await file.arrayBuffer());
				const compressContent = /<html[^>]* data-sfz[^>]*>/i.test(content);
				if (compressContent) {
					await init({ content: file, compressContent }, { filename: file.name });
					droppedArchiveContent = Array.from(new Uint8Array(await file.arrayBuffer()));
				} else {
					const isMHTML = /\.mhtml?$|\.mht$/i.test(file.name);
					let filename = file.name || "Untitled.html";
					filename = filename.replace(/(\.mhtml|\.mht)$/i, ".html");
					if (!filename.endsWith(".html")) {
						filename += ".html";
					}
					if (isMHTML) {
						const { data } = await convert(content, { DOMParser: globalThis.DOMParser });
						content = data;
					}
					await init({ content }, { filename, isMHTML });
				}
			}
		};
	}

	async function init({ content, password, compressContent, url, pagePath }, { filename, reset, isMHTML } = {}) {
		await initConstants();
		if (compressContent) {
			const zipOptions = {
				useWebWorkers: false
			};
			if (pagePath === undefined) {
				resetArchive();
				if (await initArchive(content, password, zipOptions, filename)) {
					return;
				}
			}
			const { docContent, origDocContent, resources, url } = await singlefile.helper.extract(content, {
				password,
				prompt,
				zipOptions,
				pagePath,
				excludedPaths: archivePages && !pagePath ? [PAGES_PREFIX, RESERVED_FILES_PREFIX] : undefined,
				aliases: archivePages && pagePath !== undefined ? archiveManifest.aliases : undefined
			});
			pageResources = resources;
			pageUrl = url;
			pageCompressContent = true;
			const contentDocument = (new DOMParser()).parseFromString(docContent, "text/html");
			if (detectSavedPage(contentDocument)) {
				const { saveUrl } = singlefile.helper.extractInfobarData(contentDocument);
				pageUrl = saveUrl;
				await singlefile.helper.display(document, docContent, { disableFramePointerEvents: true });
				const infobarElement = document.querySelector(singlefile.helper.INFOBAR_TAGNAME);
				if (infobarElement) {
					infobarElement.remove();
				}
				initPage();
				if (!archivePages) {
					let icon;
					const origContentDocument = (new DOMParser()).parseFromString(origDocContent, "text/html");
					const iconElement = origContentDocument.querySelector("link[rel*=icon]");
					if (iconElement) {
						const iconResource = resources.find(resource => resource.filename == iconElement.getAttribute("href"));
						if (iconResource && iconResource.content) {
							icon = await getDataURI(await (await fetch(iconResource.content)).blob());
						} else {
							icon = iconElement.href;
						}
					}
					window.parent.postMessage(JSON.stringify({
						method: "onInit",
						title: document.title,
						icon,
						filename,
						reset,
						formatPageEnabled: isProbablyReaderable(document)
					}), "*");
				}
			}
		} else {
			const contentDocument = (new DOMParser()).parseFromString(content, "text/html");
			if (detectSavedPage(contentDocument) || isMHTML) {
				resetArchive();
				pageCompressContent = false;
				droppedArchiveContent = undefined;
				if (!isMHTML) {
					const { saveUrl } = singlefile.helper.extractInfobarData(contentDocument);
					pageUrl = saveUrl;
				}
				if (contentDocument.doctype) {
					if (document.doctype) {
						document.replaceChild(contentDocument.doctype, document.doctype);
					} else {
						document.insertBefore(contentDocument.doctype, document.documentElement);
					}
				} else if (document.doctype) {
					document.doctype.remove();
				}
				const infobarElement = contentDocument.querySelector(singlefile.helper.INFOBAR_TAGNAME);
				if (infobarElement) {
					infobarElement.remove();
				}
				contentDocument.querySelectorAll("noscript").forEach(element => {
					element.setAttribute(DISABLED_NOSCRIPT_ATTRIBUTE_NAME, element.innerHTML);
					element.textContent = "";
				});
				disableFramePointerEvents(contentDocument);
				document.replaceChild(contentDocument.documentElement, document.documentElement);
				initPageContent();
				const iconElement = document.querySelector("link[rel*=icon]");
				window.parent.postMessage(JSON.stringify({
					method: "onInit",
					title: document.title,
					icon: iconElement && iconElement.href,
					filename,
					reset,
					formatPageEnabled: isProbablyReaderable(document)
				}), "*");
			}
		}
		if (!pageUrl && url) {
			pageUrl = url;
		}
	}

	async function initArchive(content, password, zipOptions, filename) {
		const { resources } = await singlefile.helper.extract(content, { password, prompt, zipOptions, pagePath: RESERVED_FILES_PREFIX });
		const pagesResource = resources.find(resource => RESERVED_FILES_PREFIX + resource.filename == PAGES_FILENAME);
		if (!pagesResource) {
			return false;
		}
		const manifest = JSON.parse(await (await fetch(pagesResource.content)).text());
		archiveManifest = manifest;
		pageArchiveContent = content;
		archivePassword = password;
		archivePages = manifest.pages || [];
		archiveUrlToPath = new Map();
		archivePages.forEach(page => {
			if (page.url) {
				archiveUrlToPath.set(page.url, page.path);
			}
			if (page.originalUrls) {
				page.originalUrls.forEach(originalUrl => archiveUrlToPath.set(originalUrl, page.path));
			}
		});
		const tocResource = resources.find(resource => RESERVED_FILES_PREFIX + resource.filename == TOC_FILENAME);
		archiveTocPresent = Boolean(tocResource);
		archiveTocContent = tocResource ? await (await fetch(tocResource.content)).text() : getDefaultArchiveTocContent();
		stashedArchivePages = new Map();
		modifiedArchivePagePaths = new Set();
		window.parent.postMessage(JSON.stringify({
			method: "onInitArchive",
			pages: archivePages.map(page => ({ path: page.path, url: page.url, title: page.title })),
			filename
		}), "*");
		return true;
	}

	function resetArchive() {
		pageArchiveContent = archivePages = archiveManifest = archivePassword = archiveUrlToPath = archiveTocContent = stashedArchivePages = modifiedArchivePagePaths = currentArchivePagePath = undefined;
		archiveTocDisplayed = archiveTocPresent = false;
	}

	async function openArchivePage(pagePath) {
		stashArchivePage();
		archiveTocDisplayed = false;
		currentArchivePagePath = pagePath;
		removedElements = [];
		removedElementIndex = 0;
		previousContent = null;
		const stashedPage = stashedArchivePages.get(pagePath);
		if (stashedPage) {
			stashedArchivePages.delete(pagePath);
			pageResources = stashedPage.resources;
			pageUrl = stashedPage.url;
			pageCompressContent = true;
			document.replaceChild(stashedPage.content, document.documentElement);
			initPage();
		} else {
			await init({ content: pageArchiveContent, password: archivePassword, compressContent: true, pagePath });
		}
		document.addEventListener("click", onArchiveLinkClick, true);
		window.parent.postMessage(JSON.stringify({
			method: "onArchivePageDisplayed",
			pagePath,
			title: document.title,
			formatPageEnabled: isProbablyReaderable(document),
			modified: modifiedArchivePagePaths.size > 0
		}), "*");
	}

	async function displayArchiveToc() {
		stashArchivePage();
		archiveTocDisplayed = true;
		currentArchivePagePath = undefined;
		const tocDocument = (new DOMParser()).parseFromString(archiveTocContent, "text/html");
		const styleElement = tocDocument.createElement("style");
		styleElement.textContent = MODIFIED_PAGE_STYLE;
		tocDocument.head.appendChild(styleElement);
		tocDocument.querySelectorAll("a[href]").forEach(anchorElement => {
			const pagePath = getArchivePagePath(anchorElement.getAttribute("href"));
			if (pagePath !== undefined && modifiedArchivePagePaths.has(pagePath)) {
				anchorElement.classList.add(MODIFIED_PAGE_CLASS);
			}
		});
		document.replaceChild(document.importNode(tocDocument.documentElement, true), document.documentElement);
		document.addEventListener("click", onArchiveLinkClick, true);
		window.parent.postMessage(JSON.stringify({
			method: "onArchiveTocDisplayed",
			modified: modifiedArchivePagePaths.size > 0
		}), "*");
	}

	async function sendArchiveContent(message) {
		const displayedPagePath = currentArchivePagePath;
		const displayedToc = archiveTocDisplayed;
		const pages = [];
		for (const page of archivePages) {
			if (modifiedArchivePagePaths.has(page.path)) {
				if (page.path !== currentArchivePagePath || archiveTocDisplayed) {
					await openArchivePage(page.path);
				}
				pages.push({
					path: page.path,
					content: getContent(message.compressHTML),
					title: document.title
				});
			}
		}
		if (displayedToc) {
			await displayArchiveToc();
		} else if (displayedPagePath !== undefined && displayedPagePath !== currentArchivePagePath) {
			await openArchivePage(displayedPagePath);
		}
		const archiveContent = Array.isArray(pageArchiveContent) ? pageArchiveContent : Array.from(new Uint8Array(await pageArchiveContent.arrayBuffer()));
		window.parent.postMessage(JSON.stringify({
			method: "setContent",
			compressContent: true,
			multiPageArchive: true,
			archiveContent,
			pages,
			manifest: archiveManifest,
			tocPage: archiveTocPresent,
			foregroundSave: message.foregroundSave
		}), "*");
	}

	function stashArchivePage() {
		if (archivePages && !archiveTocDisplayed && currentArchivePagePath !== undefined) {
			serializeShadowRoots(document);
			stashedArchivePages.set(currentArchivePagePath, {
				content: document.documentElement,
				resources: pageResources,
				url: pageUrl
			});
		}
	}

	function getArchivePagePath(href) {
		if (archiveUrlToPath.has(href)) {
			return archiveUrlToPath.get(href);
		}
		if (href.endsWith(INDEX_FILENAME)) {
			const pagePath = href.substring(0, href.length - INDEX_FILENAME.length);
			if (archivePages.some(page => page.path == pagePath)) {
				return pagePath;
			}
		}
	}

	function onArchiveLinkClick(event) {
		if (archivePages && event.target.closest) {
			const anchorElement = event.target.closest("a[href]");
			if (anchorElement) {
				const pagePath = getArchivePagePath(anchorElement.getAttribute("href"));
				if (pagePath !== undefined) {
					event.preventDefault();
					event.stopPropagation();
					window.parent.postMessage(JSON.stringify({ method: "onNavigateArchivePage", pagePath }), "*");
				} else if (archiveTocDisplayed) {
					event.preventDefault();
				}
			}
		}
	}

	function getDefaultArchiveTocContent() {
		return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Table of contents</title></head><body><main><ul>" +
			archivePages.map(page => "<li><a href=\"" + escapeArchiveHTML(page.path + INDEX_FILENAME) + "\">" + escapeArchiveHTML(page.title || page.url || page.path) + "</a></li>").join("") +
			"</ul></main></body></html>";
	}

	function escapeArchiveHTML(value) {
		return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
	}

	function loadOptionsFromPage(doc) {
		const optionsElement = doc.body.querySelector("script[type=\"application/json\"][" + SCRIPT_OPTIONS + "]");
		if (optionsElement) {
			return JSON.parse(optionsElement.textContent);
		}
	}

	function initPage() {
		disableFramePointerEvents(document);
		initPageContent();
	}

	function disableFramePointerEvents(doc) {
		doc.querySelectorAll("iframe").forEach(element => {
			const pointerEvents = "pointer-events";
			if (element.style.getPropertyValue(pointerEvents) != "none" || element.style.getPropertyPriority(pointerEvents) != "important") {
				element.style.setProperty("--sf-" + pointerEvents, element.style.getPropertyValue(pointerEvents), element.style.getPropertyPriority(pointerEvents));
			}
			element.style.setProperty(pointerEvents, "none", "important");
		});
	}

	function initPageContent() {
		document.querySelectorAll("[data-single-file-note-refs]").forEach(noteRefElement => noteRefElement.dataset.singleFileNoteRefs = noteRefElement.dataset.singleFileNoteRefs.replace(/,/g, " "));
		deserializeShadowRoots(document);
		singlefile.helper.fixInvalidNesting(document);
		notes = singlefile.helper.notes.init(document, { editable: true, onUpdate });
		notes.reflowNotes();
		notes.waitResourcesLoad().then(notes.reflowNotes);
		notes.watchNotesLayout();
		document.querySelectorAll(NOTE_TAGNAME).forEach(containerElement => notes.attachNoteListeners(containerElement));
		singlefile.helper.notes.insertHighlightsStylesheet(document);
		document.documentElement.onmousedown = onMouseDown;
		document.documentElement.onmouseup = document.documentElement.ontouchend = onMouseUp;
		document.documentElement.onmouseover = onMouseOver;
		document.documentElement.onmouseout = onMouseOut;
		document.documentElement.onkeydown = onKeyDown;
		document.documentElement.ontouchstart = document.documentElement.ontouchmove = onTouchMove;
		window.onclick = onClick;
	}

	function onClick(event) {
		event.preventDefault();
		const editing = highlightSelectionMode || removeHighlightMode || cuttingMode || cuttingOuterMode || document.body.isContentEditable;
		if (!editing && event.target.closest) {
			const linkElement = event.target.closest("a[href^='#'], area[href^='#']");
			if (linkElement) {
				scrollToFragment(linkElement.getAttribute("href").substring(1));
			}
		}
	}

	function scrollToFragment(fragment) {
		let targetElement = findFragmentTarget(fragment);
		if (!targetElement) {
			try {
				targetElement = findFragmentTarget(decodeURIComponent(fragment));
			} catch {
				// ignored
			}
		}
		if (targetElement) {
			targetElement.scrollIntoView();
		} else if (!fragment || fragment.toLowerCase() == "top") {
			window.scrollTo(0, 0);
		}
	}

	function findFragmentTarget(fragment) {
		if (fragment) {
			return document.getElementById(fragment) || document.querySelector("a[name=" + JSON.stringify(fragment) + "]");
		}
	}

	async function initConstants() {
		if (!NOTES_SCRIPT) {
			NOTES_SCRIPT = await (await fetch("/lib/single-file-notes.js")).text();
		}
	}

	function onMouseDown(event) {
		if ((cuttingMode || cuttingOuterMode) && cuttingPath) {
			event.preventDefault();
		}
	}

	function onMouseUp(event) {
		if (highlightSelectionMode) {
			event.preventDefault();
			highlightSelection();
			onUpdate(false);
		}
		if (removeHighlightMode) {
			event.preventDefault();
			let element = event.target, done;
			while (element && !done) {
				if (element.classList.contains(HIGHLIGHT_CLASS)) {
					document.querySelectorAll("." + HIGHLIGHT_CLASS + "[data-singlefile-highlight-id=" + JSON.stringify(element.dataset.singlefileHighlightId) + "]").forEach(highlightedElement => {
						resetHighlightedElement(highlightedElement);
						onUpdate(false);
					});
					done = true;
				}
				element = element.parentElement;
			}
		}
		notes.onMouseUp(event);
		if ((cuttingMode || cuttingOuterMode) && cuttingPath) {
			event.preventDefault();
			if (event.ctrlKey) {
				const element = cuttingPath[cuttingPathIndex];
				element.classList.toggle(cuttingMode ? CUT_SELECTED_CLASS : CUT_OUTER_SELECTED_CLASS);
			} else {
				validateCutElement(event.shiftKey);
			}
		}
	}

	function onMouseOver(event) {
		if (cuttingMode || cuttingOuterMode) {
			const target = event.target;
			if (target.classList) {
				let ancestorFound;
				document.querySelectorAll("." + (cuttingMode ? CUT_SELECTED_CLASS : CUT_OUTER_SELECTED_CLASS)).forEach(element => {
					if (element == target || isAncestor(element, target) || isAncestor(target, element)) {
						ancestorFound = element;
					}
				});
				if (ancestorFound) {
					cuttingPath = [ancestorFound];
				} else {
					cuttingPath = getParents(event.target);
				}
				cuttingPathIndex = 0;
				highlightCutElement();
			}
		}
	}

	function onMouseOut() {
		if (cuttingMode || cuttingOuterMode) {
			if (cuttingPath) {
				unhighlightCutElement();
				cuttingPath = null;
			}
		}
	}

	function onTouchMove(event) {
		if (cuttingMode || cuttingOuterMode) {
			event.preventDefault();
			const { clientX, clientY } = singlefile.helper.notes.getPosition(event);
			const target = document.elementFromPoint(clientX, clientY);
			if (cuttingTouchTarget != target) {
				onMouseOut();
				if (target) {
					cuttingTouchTarget = target;
					onMouseOver({ target });
				}
			}
		}
	}

	function onKeyDown(event) {
		if (cuttingMode || cuttingOuterMode) {
			if (event.code == "Tab") {
				if (cuttingPath) {
					const delta = event.shiftKey ? -1 : 1;
					let element = cuttingPath[cuttingPathIndex];
					let nextElement = cuttingPath[cuttingPathIndex + delta];
					if (nextElement) {
						let pathIndex = cuttingPathIndex + delta;
						while (
							nextElement &&
							(
								(delta == 1 &&
									element.getBoundingClientRect().width >= nextElement.getBoundingClientRect().width &&
									element.getBoundingClientRect().height >= nextElement.getBoundingClientRect().height) ||
								(delta == -1 &&
									element.getBoundingClientRect().width <= nextElement.getBoundingClientRect().width &&
									element.getBoundingClientRect().height <= nextElement.getBoundingClientRect().height))) {
							pathIndex += delta;
							nextElement = cuttingPath[pathIndex];
						}
						if (nextElement && nextElement.classList && nextElement != document.body && nextElement != document.documentElement) {
							unhighlightCutElement();
							cuttingPathIndex = pathIndex;
							highlightCutElement();
						}
					}
				}
				event.preventDefault();
			}
			if (event.code == "Space") {
				if (cuttingPath) {
					if (event.ctrlKey) {
						const element = cuttingPath[cuttingPathIndex];
						element.classList.add(cuttingMode ? CUT_SELECTED_CLASS : CUT_OUTER_SELECTED_CLASS);
					} else {
						validateCutElement(event.shiftKey);
					}
					event.preventDefault();
				}
			}
			if (event.code == "Escape") {
				resetSelectedElements();
				event.preventDefault();
			}
			if (event.key.toLowerCase() == "z" && event.ctrlKey) {
				if (event.shiftKey) {
					redoCutPage();
				} else {
					undoCutPage();
				}
				event.preventDefault();
			}
		}
		if (event.key.toLowerCase() == "s" && event.ctrlKey) {
			window.parent.postMessage(JSON.stringify({ "method": "savePage" }), "*");
			event.preventDefault();
		}
		if (event.key.toLowerCase() == "p" && event.ctrlKey) {
			printPage();
			event.preventDefault();
		}
	}

	function printPage() {
		unhighlightCutElement();
		resetSelectedElements();
		window.print();
	}

	function highlightCutElement() {
		const element = cuttingPath[cuttingPathIndex];
		element.classList.add(cuttingMode ? CUT_HOVER_CLASS : CUT_OUTER_HOVER_CLASS);
	}

	function unhighlightCutElement() {
		if (cuttingPath) {
			const element = cuttingPath[cuttingPathIndex];
			element.classList.remove(CUT_HOVER_CLASS);
			element.classList.remove(CUT_OUTER_HOVER_CLASS);
		}
	}

	function disableHighlight(doc = document) {
		if (highlightColor) {
			doc.documentElement.classList.remove(highlightColor + "-mode");
		}
	}

	function undoCutPage() {
		if (removedElementIndex) {
			removedElements[removedElementIndex - 1].forEach(element => element.classList.remove(REMOVED_CONTENT_CLASS));
			removedElementIndex--;
		}
	}

	function redoCutPage() {
		if (removedElementIndex < removedElements.length) {
			removedElements[removedElementIndex].forEach(element => element.classList.add(REMOVED_CONTENT_CLASS));
			removedElementIndex++;
		}
	}

	function validateCutElement(invert) {
		const selectedElement = cuttingPath[cuttingPathIndex];
		if ((cuttingMode && !invert) || (cuttingOuterMode && invert)) {
			if (document.documentElement != selectedElement && selectedElement.tagName.toLowerCase() != NOTE_TAGNAME) {
				const elementsRemoved = [selectedElement].concat(...document.querySelectorAll("." + CUT_SELECTED_CLASS + ",." + CUT_SELECTED_CLASS + " *,." + CUT_HOVER_CLASS + " *"));
				resetSelectedElements();
				if (elementsRemoved.length) {
					elementsRemoved.forEach(element => {
						unhighlightCutElement(element);
						if (element.tagName.toLowerCase() == NOTE_TAGNAME) {
							notes.resetAnchorNote(element);
						} else {
							element.classList.add(REMOVED_CONTENT_CLASS);
						}
					});
					removedElements[removedElementIndex] = elementsRemoved;
					removedElementIndex++;
					removedElements.length = removedElementIndex;
					onUpdate(false);
				}
			}
		} else {
			if (document.documentElement != selectedElement && selectedElement.tagName.toLowerCase() != NOTE_TAGNAME) {
				const elements = [];
				const searchSelector = "*:not(style):not(meta):not(." + REMOVED_CONTENT_CLASS + ")";
				const elementsKept = [selectedElement].concat(...document.querySelectorAll("." + CUT_OUTER_SELECTED_CLASS));
				document.body.querySelectorAll(searchSelector).forEach(element => {
					let removed = true;
					elementsKept.forEach(elementKept => removed = removed && (elementKept != element && !isAncestor(elementKept, element) && !isAncestor(element, elementKept)));
					if (removed) {
						if (element.tagName.toLowerCase() == NOTE_TAGNAME) {
							notes.resetAnchorNote(element);
						} else {
							elements.push(element);
						}
					}
				});
				elementsKept.forEach(elementKept => {
					unhighlightCutElement(elementKept);
					const elementKeptRect = elementKept.getBoundingClientRect();
					elementKept.querySelectorAll(searchSelector).forEach(descendant => {
						const descendantRect = descendant.getBoundingClientRect();
						if (descendantRect.width && descendantRect.height && (
							descendantRect.left + descendantRect.width < elementKeptRect.left ||
							descendantRect.right > elementKeptRect.right + elementKeptRect.width ||
							descendantRect.top + descendantRect.height < elementKeptRect.top ||
							descendantRect.bottom > elementKeptRect.bottom + elementKeptRect.height
						)) {
							elements.push(descendant);
						}
					});
				});
				resetSelectedElements();
				if (elements.length) {
					elements.forEach(element => element.classList.add(REMOVED_CONTENT_CLASS));
					removedElements[removedElementIndex] = elements;
					removedElementIndex++;
					removedElements.length = removedElementIndex;
					onUpdate(false);
				}
			}
		}
	}

	function resetSelectedElements(doc = document) {
		doc.querySelectorAll("." + CUT_OUTER_SELECTED_CLASS + ",." + CUT_SELECTED_CLASS).forEach(element => {
			element.classList.remove(CUT_OUTER_SELECTED_CLASS);
			element.classList.remove(CUT_SELECTED_CLASS);
		});
	}

	function highlightSelection() {
		let highlightId = 0;
		document.querySelectorAll("." + HIGHLIGHT_CLASS).forEach(highlightedElement => highlightId = Math.max(highlightId, highlightedElement.dataset.singlefileHighlightId));
		highlightId++;
		const selection = window.getSelection();
		const highlightedNodes = new Set();
		for (let indexRange = 0; indexRange < selection.rangeCount; indexRange++) {
			const range = selection.getRangeAt(indexRange);
			if (!range.collapsed) {
				if (range.commonAncestorContainer.nodeType == range.commonAncestorContainer.TEXT_NODE) {
					let contentText = range.startContainer.splitText(range.startOffset);
					contentText = contentText.splitText(range.endOffset);
					addHighLightedNode(contentText.previousSibling);
				} else {
					const treeWalker = document.createTreeWalker(range.commonAncestorContainer, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
					let highlightNodes;
					while (treeWalker.nextNode()) {
						if (highlightNodes && !treeWalker.currentNode.contains(range.endContainer)) {
							addHighLightedNode(treeWalker.currentNode);
						}
						if (treeWalker.currentNode == range.startContainer) {
							if (range.startContainer.nodeType == range.startContainer.TEXT_NODE) {
								const contentText = range.startContainer.splitText(range.startOffset);
								treeWalker.nextNode();
								addHighLightedNode(contentText);
							} else {
								addHighLightedNode(range.startContainer.childNodes[range.startOffset]);
							}
							highlightNodes = true;
						}
						if (treeWalker.currentNode == range.endContainer) {
							if (range.endContainer.nodeType == range.endContainer.TEXT_NODE) {
								const contentText = range.endContainer.splitText(range.endOffset);
								treeWalker.nextNode();
								addHighLightedNode(contentText.previousSibling);
							} else {
								addHighLightedNode(range.endContainer.childNodes[range.endOffset]);
							}
							highlightNodes = false;
						}
					}
					range.collapse();
				}
			}
		}
		highlightedNodes.forEach(node => highlightNode(node));

		function addHighLightedNode(node) {
			if (node && node.textContent.trim()) {
				if (node.nodeType == node.TEXT_NODE && node.parentElement.childNodes.length == 1 && node.parentElement.classList.contains(HIGHLIGHT_CLASS)) {
					highlightedNodes.add(node.parentElement);
				} else {
					highlightedNodes.add(node);
				}
			}
		}

		function highlightNode(node) {
			if (node.nodeType == node.ELEMENT_NODE) {
				resetHighlightedElement(node);
				node.classList.add(HIGHLIGHT_CLASS);
				node.classList.add(highlightColor);
				node.dataset.singlefileHighlightId = highlightId;
			} else if (node.parentElement) {
				highlightTextNode(node);
			}
		}

		function highlightTextNode(node) {
			const spanElement = document.createElement("span");
			spanElement.classList.add(HIGHLIGHT_CLASS);
			spanElement.classList.add(highlightColor);
			spanElement.textContent = node.textContent;
			spanElement.dataset.singlefileHighlightId = highlightId;
			node.parentNode.replaceChild(spanElement, node);
			return spanElement;
		}
	}

	function getParents(element) {
		const path = [];
		while (element) {
			path.push(element);
			element = element.parentElement;
		}
		return path;
	}

	function formatPage(applySystemTheme, contentWidth) {
		if (pageCompressContent) {
			serializeShadowRoots(document);
			previousContent = document.documentElement.cloneNode(true);
			deserializeShadowRoots(document);
		} else {
			previousContent = getContent(false);
		}
		const shadowRoots = {};
		const noteOffsets = {};
		const classesToPreserve = ["single-file-highlight", "single-file-highlight-yellow", "single-file-highlight-green", "single-file-highlight-pink", "single-file-highlight-blue"];
		document.querySelectorAll(NOTE_TAGNAME).forEach(containerElement => {
			shadowRoots[containerElement.dataset.noteId] = containerElement.shadowRoot;
			noteOffsets[containerElement.dataset.noteId] = { x: containerElement.dataset.noteOffsetX, y: containerElement.dataset.noteOffsetY };
			const className = "singlefile-note-id-" + containerElement.dataset.noteId;
			containerElement.classList.add(className);
			classesToPreserve.push(className);
		});
		const optionsElement = document.querySelector("script[type=\"application/json\"][" + SCRIPT_OPTIONS + "]");
		const article = new Readability(document, { classesToPreserve }).parse();
		const articleMetadata = Object.assign({}, article);
		delete articleMetadata.content;
		delete articleMetadata.textContent;
		for (const key in articleMetadata) {
			if (articleMetadata[key] == null) {
				delete articleMetadata[key];
			}
		}
		removedElements = [];
		removedElementIndex = 0;
		document.body.innerHTML = "";
		const domParser = new DOMParser();
		const doc = domParser.parseFromString(article.content, "text/html");
		const contentEditable = document.body.contentEditable;
		document.documentElement.replaceChild(doc.body, document.body);
		if (optionsElement) {
			document.body.appendChild(optionsElement);
		}
		document.querySelectorAll(NOTE_TAGNAME).forEach(containerElement => {
			const noteId = (Array.from(containerElement.classList).find(className => /singlefile-note-id-\d+/.test(className))).split("singlefile-note-id-")[1];
			containerElement.classList.remove("singlefile-note-id-" + noteId);
			containerElement.dataset.noteId = noteId;
			const noteOffset = noteOffsets[noteId];
			if (noteOffset && noteOffset.x !== undefined && noteOffset.y !== undefined && document.querySelector("[data-single-file-note-refs~=\"" + noteId + "\"]")) {
				containerElement.dataset.noteOffsetX = noteOffset.x;
				containerElement.dataset.noteOffsetY = noteOffset.y;
			}
			if (!containerElement.shadowRoot) {
				containerElement.attachShadow({ mode: "open" });
				containerElement.shadowRoot.appendChild(shadowRoots[noteId]);
			}
		});
		document.querySelectorAll(NOTE_TAGNAME).forEach(containerElement => shadowRoots[containerElement.dataset.noteId].childNodes.forEach(node => containerElement.shadowRoot.appendChild(node)));
		document.body.contentEditable = contentEditable;
		document.head.querySelectorAll("style").forEach(styleElement => styleElement.remove());
		const styleElement = document.createElement("style");
		styleElement.textContent = getStyleFormattedPage(contentWidth);
		document.head.appendChild(styleElement);
		document.body.classList.add("moz-reader-content");
		document.body.classList.add("content-width6");
		document.body.classList.add("reader-show-element");
		document.body.classList.add("sans-serif");
		document.body.classList.add("container");
		document.body.classList.add("line-height4");
		const prefersColorSchemeDark = matchMedia("(prefers-color-scheme: dark)");
		if (applySystemTheme && prefersColorSchemeDark && prefersColorSchemeDark.matches) {
			document.body.classList.add("dark");
		}
		document.body.style.setProperty("display", "block");
		document.body.style.setProperty("padding", "24px");
		const titleElement = document.createElement("h1");
		titleElement.classList.add("reader-title");
		titleElement.textContent = article.title;
		document.body.insertBefore(titleElement, document.body.firstChild);
		const existingMetaDataElement = document.querySelector("script[id=singlefile-readability-metadata]");
		if (existingMetaDataElement) {
			existingMetaDataElement.remove();
		}
		const metaDataElement = document.createElement("script");
		metaDataElement.type = "application/json";
		metaDataElement.id = "singlefile-readability-metadata";
		metaDataElement.textContent = JSON.stringify(articleMetadata, null, 2);
		document.head.appendChild(metaDataElement);
		document.querySelectorAll("a[href]").forEach(element => {
			const href = element.getAttribute("href").trim();
			if (href.startsWith(document.baseURI + "#")) {
				element.setAttribute("href", href.substring(document.baseURI.length));
			}
		});
		singlefile.helper.notes.insertHighlightsStylesheet(document);
		notes = singlefile.helper.notes.init(document, { editable: true, onUpdate });
		document.querySelectorAll(NOTE_TAGNAME).forEach(containerElement => notes.attachNoteListeners(containerElement));
		notes.reflowNotes();
		onUpdate(false);
	}

	async function cancelFormatPage() {
		if (previousContent) {
			const contentEditable = document.body.contentEditable;
			if (pageCompressContent) {
				document.replaceChild(previousContent, document.documentElement);
				deserializeShadowRoots(document);
				initPage();
			} else {
				await init({ content: previousContent }, { reset: true });
			}
			document.body.contentEditable = contentEditable;
			onUpdate(false);
			previousContent = null;
		}
	}

	function getContent(compressHTML) {
		notes.saveNoteOffsets();
		unhighlightCutElement();
		singlefile.helper.markInvalidNesting(document);
		serializeShadowRoots(document);
		const doc = document.cloneNode(true);
		disableHighlight(doc);
		resetSelectedElements(doc);
		deserializeShadowRoots(doc);
		deserializeShadowRoots(document);
		doc.documentElement.classList.remove(CUT_MODE_CLASS);
		doc.querySelectorAll("[" + DISABLED_NOSCRIPT_ATTRIBUTE_NAME + "]").forEach(element => {
			element.textContent = element.getAttribute(DISABLED_NOSCRIPT_ATTRIBUTE_NAME);
			element.removeAttribute(DISABLED_NOSCRIPT_ATTRIBUTE_NAME);
		});
		doc.querySelectorAll("." + MASK_CLASS + ", " + singlefile.helper.INFOBAR_TAGNAME + ", ." + REMOVED_CONTENT_CLASS).forEach(element => element.remove());
		if (includeInfobar) {
			const options = singlefile.helper.extractInfobarData(doc);
			options.openInfobar = openInfobar;
			options.animateInfobar = animateInfobar;
			options.infobarPositionAbsolute = infobarPositionAbsolute;
			options.infobarPositionTop = infobarPositionTop;
			options.infobarPositionRight = infobarPositionRight;
			options.infobarPositionBottom = infobarPositionBottom;
			options.infobarPositionLeft = infobarPositionLeft;
			singlefile.helper.appendInfobar(doc, options);
		}
		doc.querySelectorAll("." + HIGHLIGHT_CLASS).forEach(noteElement => noteElement.classList.remove(HIGHLIGHT_HIDDEN_CLASS));
		singlefile.helper.notes.serializeNotes(doc);
		doc.querySelectorAll("iframe").forEach(element => {
			const pointerEvents = "pointer-events";
			const savedProperty = "--sf-" + pointerEvents;
			const savedValue = element.style.getPropertyValue(savedProperty);
			if (savedValue) {
				element.style.setProperty(pointerEvents, savedValue, element.style.getPropertyPriority(savedProperty));
				element.style.removeProperty(savedProperty);
			} else {
				element.style.removeProperty(pointerEvents);
			}
		});
		doc.body.removeAttribute("contentEditable");
		if (pageCompressContent) {
			const pageFilename = pageResources
				.filter(resource => resource.filename.endsWith("index.html"))
				.sort((resourceLeft, resourceRight) => resourceLeft.filename.length - resourceRight.filename.length)[0].filename;
			const resources = pageResources.filter(resource => resource.parentResources.includes(pageFilename));
			doc.querySelectorAll("[src]").forEach(element => resources.forEach(resource => {
				if (element.src == resource.content) {
					element.src = resource.name;
				}
			}));
			let content = singlefile.helper.serialize(doc, compressHTML);
			resources.sort((resourceLeft, resourceRight) => resourceRight.content.length - resourceLeft.content.length);
			resources.forEach(resource => content = content.replaceAll(resource.content, resource.name));
			return content + "<script " + SCRIPT_TEMPLATE_SHADOW_ROOT + ">" + NOTES_SCRIPT + "</script>";
		} else {
			return singlefile.helper.serialize(doc, compressHTML) + "<script " + SCRIPT_TEMPLATE_SHADOW_ROOT + ">" + NOTES_SCRIPT + "</script>";
		}
	}

	function onUpdate(saved) {
		if (archivePages && !saved && !archiveTocDisplayed && currentArchivePagePath !== undefined) {
			modifiedArchivePagePaths.add(currentArchivePagePath);
		}
		window.parent.postMessage(JSON.stringify({ "method": "onUpdate", saved }), "*");
	}

	function resetHighlightedElement(element) {
		element.classList.remove(HIGHLIGHT_CLASS);
		element.classList.remove("single-file-highlight-yellow");
		element.classList.remove("single-file-highlight-pink");
		element.classList.remove("single-file-highlight-blue");
		element.classList.remove("single-file-highlight-green");
		delete element.dataset.singlefileHighlightId;
	}

	function serializeShadowRoots(node) {
		node.querySelectorAll("*").forEach(element => {
			const shadowRoot = singlefile.helper.notes.getShadowRoot(element);
			if (shadowRoot) {
				serializeShadowRoots(shadowRoot);
				const templateElement = document.createElement("template");
				templateElement.setAttribute(SHADOWROOT_ATTRIBUTE_NAME, "open");
				Array.from(shadowRoot.childNodes).forEach(childNode => templateElement.appendChild(childNode));
				element.appendChild(templateElement);
			}
		});
	}

	function deserializeShadowRoots(node) {
		node.querySelectorAll(`template[${SHADOWROOT_ATTRIBUTE_NAME}]`).forEach(element => {
			if (element.parentElement) {
				let shadowRoot = singlefile.helper.notes.getShadowRoot(element.parentElement);
				if (shadowRoot) {
					Array.from(element.childNodes).forEach(node => shadowRoot.appendChild(node));
					element.remove();
				} else {
					try {
						shadowRoot = element.parentElement.attachShadow({ mode: "open" });
						const contentDocument = (new DOMParser()).parseFromString(element.innerHTML, "text/html");
						Array.from(contentDocument.head.childNodes).forEach(node => shadowRoot.appendChild(node));
						Array.from(contentDocument.body.childNodes).forEach(node => shadowRoot.appendChild(node));
						if (!element.childNodes.length) {
							element.remove();
						}
						// eslint-disable-next-line no-unused-vars
					} catch (error) {
						// ignored
					}
				}
				if (shadowRoot) {
					deserializeShadowRoots(shadowRoot);
				}
			}
		});
	}

	function getStyleFormattedPage(contentWidth) {
		return `
	/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Avoid adding ID selector rules in this style sheet, since they could
 * inadvertently match elements in the article content. */

:root {
  --grey-90-a10: rgba(12, 12, 13, 0.1);
  --grey-90-a20: rgba(12, 12, 13, 0.2);
  --grey-90-a30: rgba(12, 12, 13, 0.3);
  --grey-90-a80: rgba(12, 12, 13, 0.8);
  --grey-30: #d7d7db;
  --blue-40: #45a1ff;
  --blue-40-a30: rgba(69, 161, 255, 0.3);
  --blue-60: #0060df;
  --body-padding: 64px;
  --font-size: 12;
  --content-width: ${contentWidth}em;
  --line-height: 1.6em;
}

body {
  --main-background: #fff;
  --main-foreground: #333;
  --font-color: #000000;
  --primary-color: #0B83FF;
  --toolbar-border: var(--grey-90-a20);
  --toolbar-transparent-border: transparent;
  --toolbar-box-shadow: var(--grey-90-a10);
  --toolbar-button-background: transparent;
  --toolbar-button-background-hover: var(--grey-90-a10);
  --toolbar-button-foreground-hover: var(--font-color);
  --toolbar-button-background-active: var(--grey-90-a20);
  --toolbar-button-foreground-active: var(--primary-color);
  --toolbar-button-border: transparent;
  --toolbar-button-border-hover: transparent;
  --toolbar-button-border-active: transparent;
  --tooltip-background: var(--grey-90-a80);
  --tooltip-foreground: white;
  --tooltip-border: transparent;
  --popup-background: white;
  --popup-border: rgba(0, 0, 0, 0.12);
  --opaque-popup-border: #e0e0e0;
  --popup-line: var(--grey-30);
  --popup-shadow: rgba(49, 49, 49, 0.3);
  --popup-button-background: #edecf0;
  --popup-button-background-hover: hsla(0,0%,70%,.4);
  --popup-button-foreground-hover: var(--font-color);
  --popup-button-background-active: hsla(240,5%,5%,.15);
  --selected-background: var(--blue-40-a30);
  --selected-border: var(--blue-40);
  --font-value-border: var(--grey-30);
  --icon-fill: #3b3b3c;
  --icon-disabled-fill: #8080807F;
  --link-foreground: var(--blue-60);
  --link-selected-foreground: #333;
  --visited-link-foreground: #b5007f;
  /* light colours */
}

body.sepia {
  --main-background: #f4ecd8;
  --main-foreground: #5b4636;
  --toolbar-border: #5b4636;
}

body.dark {
  --main-background: rgb(28, 27, 34);
  --main-foreground: #eee;
  --font-color: #fff;
  --toolbar-border: #4a4a4b;
  --toolbar-box-shadow: black;
  --toolbar-button-background-hover: var(--grey-90-a30);
  --toolbar-button-background-active: var(--grey-90-a80);
  --tooltip-background: black;
  --tooltip-foreground: white;
  --popup-background: rgb(66,65,77);
  --opaque-popup-border: #434146;
  --popup-line: rgb(82, 82, 94);
  --popup-button-background: #5c5c61;
  --popup-button-background-active: hsla(0,0%,70%,.6);
  --selected-background: #3E6D9A;
  --font-value-border: #656468;
  --icon-fill: #fff;
  --icon-disabled-fill: #ffffff66;
  --link-foreground: #45a1ff;
  --link-selected-foreground: #fff;
  --visited-link-foreground: #e675fd;
  /* dark colours */
}

body.hcm {
  --main-background: Canvas;
  --main-foreground: CanvasText;
  --font-color: CanvasText;
  --primary-color: SelectedItem;
  --toolbar-border: CanvasText;
   /* We need a true transparent but in HCM this would compute to an actual color,
      so select the page's background color instead: */
  --toolbar-transparent-border: Canvas;
  --toolbar-box-shadow: Canvas;
  --toolbar-button-background: ButtonFace;
  --toolbar-button-background-hover: ButtonText;
  --toolbar-button-foreground-hover: ButtonFace;
  --toolbar-button-background-active: SelectedItem;
  --toolbar-button-foreground-active: SelectedItemText;
  --toolbar-button-border: ButtonText;
  --toolbar-button-border-hover: ButtonText;
  --toolbar-button-border-active: ButtonText;
  --tooltip-background: Canvas;
  --tooltip-foreground: CanvasText;
  --tooltip-border: CanvasText;
  --popup-background: Canvas;
  --popup-border: CanvasText;
  --opaque-popup-border: CanvasText;
  --popup-line: CanvasText;
  --popup-button-background: ButtonFace;
  --popup-button-background-hover: ButtonText;
  --popup-button-foreground-hover: ButtonFace;
  --popup-button-background-active: ButtonText;
  --selected-background: Canvas;
  --selected-border: SelectedItem;
  --font-value-border: CanvasText;
  --icon-fill: ButtonText;
  --icon-disabled-fill: GrayText;
  --link-foreground: LinkText;
  --link-selected-foreground: ActiveText;
  --visited-link-foreground: VisitedText;
}

body {
  margin: 0;
  padding: var(--body-padding);
  background-color: var(--main-background);
  color: var(--main-foreground);
}

body.loaded {
  transition: color 0.4s, background-color 0.4s;
}

body.dark *::-moz-selection {
  background-color: var(--selected-background);
}

a::-moz-selection {
  color: var(--link-selected-foreground);
}

body.sans-serif,
body.sans-serif .remove-button {
  font-family: Helvetica, Arial, sans-serif;
}

body.serif,
body.serif .remove-button {
  font-family: Georgia, "Times New Roman", serif;
}

/* Override some controls and content styles based on color scheme */

body.light > .container > .header > .domain {
  border-bottom-color: #333333 !important;
}

body.sepia > .container > .header > .domain {
  border-bottom-color: #5b4636 !important;
}

body.dark > .container > .header > .domain {
  border-bottom-color: #eeeeee !important;
}

body.light blockquote {
  border-inline-start: 2px solid #333333 !important;
}

body.sepia blockquote {
  border-inline-start: 2px solid #5b4636 !important;
}

body.dark blockquote {
  border-inline-start: 2px solid #eeeeee !important;
}

.light-button {
  color: #333333;
  background-color: #ffffff;
}

.dark-button {
  color: #eeeeee;
  background-color: #1c1b22;
}

.sepia-button {
  color: #5b4636;
  background-color: #f4ecd8;
}

.auto-button {
  text-align: center;
}

@media (prefers-color-scheme: dark) {
  .auto-button {
    background-color: #1c1b22;
    color: #eeeeee;
  }
}

@media not (prefers-color-scheme: dark) {
  .auto-button {
    background-color: #ffffff;
    color: #333333;
  }
}

/* Loading/error message */

.reader-message {
  margin-top: 40px;
  display: none;
  text-align: center;
  width: 100%;
  font-size: 0.9em;
}

/* Detector element to see if we're at the top of the doc or not. */
.top-anchor {
  position: absolute;
  top: 0;
  width: 0;
  height: 5px;
  pointer-events: none;
}

/* Header */

.header {
  text-align: start;
  display: none;
}

.domain {
  font-size: 0.9em;
  line-height: 1.48em;
  padding-bottom: 4px;
  font-family: Helvetica, Arial, sans-serif;
  text-decoration: none;
  border-bottom: 1px solid;
  color: var(--link-foreground);
}

.header > h1 {
  font-size: 1.6em;
  line-height: 1.25em;
  width: 100%;
  margin: 30px 0;
  padding: 0;
}

.header > .credits {
  font-size: 0.9em;
  line-height: 1.48em;
  margin: 0 0 10px;
  padding: 0;
  font-style: italic;
}

.header > .meta-data {
  font-size: 0.65em;
  margin: 0 0 15px;
}

.reader-estimated-time {
  text-align: match-parent;
}

/* Controls toolbar */

.toolbar-container {
  position: sticky;
  z-index: 2;
  top: 32px;
  height: 0; /* take up no space, so body is at the top. */

  /* As a stick container, we're positioned relative to the body. Move us to
   * the edge of the viewport using margins, and take the width of
   * the body padding into account for calculating our width.
   */
  margin-inline-start: calc(-1 * var(--body-padding));
  width: max(var(--body-padding), calc((100% - var(--content-width)) / 2 + var(--body-padding)));
  font-size: var(--font-size); /* Needed to ensure 'em' units match, is reset for .reader-controls */
}

.toolbar {
  padding-block: 16px;
  border: 1px solid var(--toolbar-border);
  border-radius: 6px;
  box-shadow: 0 2px 8px var(--toolbar-box-shadow);

  width: 32px; /* basic width, without padding/border */

  /* padding should be 16px, except if there's not enough space for that, in
   * which case use half the available space for padding (=25% on each side).
   * The 34px here is the width + borders. We use a variable because we need
   * to know this size for the margin calculation.
   */
  --inline-padding: min(16px, calc(25% - 0.25 * 34px));
  padding-inline: var(--inline-padding);

  /* Keep a maximum of 96px distance to the body, but center once the margin
   * gets too small. We need to set the start margin, however...
   * To center, we'd want 50% of the container, but we'd subtract half our
   * own width (16px) and half the border (1px) and the inline padding.
   * When the other margin would be 96px, we want 100% - 96px - the complete
   * width of the actual toolbar (34px + 2 * padding)
   */
  margin-inline-start: max(calc(50% - 17px - var(--inline-padding)), calc(100% - 96px - 34px - 2 * var(--inline-padding)));

  font-family: Helvetica, Arial, sans-serif;
  list-style: none;
  user-select: none;
}

@media (prefers-reduced-motion: no-preference) {
  .toolbar {
    transition-property: border-color, box-shadow;
    transition-duration: 250ms;
  }

  .toolbar .toolbar-button {
    transition-property: opacity;
    transition-duration: 250ms;
  }

  .toolbar-container.scrolled .toolbar:not(:hover, :focus-within) {
    border-color: var(--toolbar-transparent-border);
    box-shadow: 0 2px 8px transparent;
  }

  .toolbar-container.scrolled .toolbar:not(:hover, :focus-within) .toolbar-button {
    opacity: 0.6;
  }

  .toolbar-container.transition-location {
    transition-duration: 250ms;
    transition-property: width;
  }
}

.toolbar-container.overlaps .toolbar-button {
  opacity: 0.1;
}

.dropdown-open .toolbar {
  border-color: var(--toolbar-transparent-border);
  box-shadow: 0 2px 8px transparent;
}

.reader-controls {
  /* We use 'em's above this node to get it to the right size. However,
   * the UI inside the toolbar should use a fixed, smaller size. */
  font-size: 11px;
}

button {
  -moz-context-properties: fill;
  color: var(--font-color);
  fill: var(--icon-fill);
}

button:disabled {
  fill: var(--icon-disabled-fill);
}

.toolbar button::-moz-focus-inner {
  border: 0;
}

.toolbar-button {
  position: relative;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 1px solid var(--toolbar-button-border);
  border-radius: 4px;
  margin: 4px 0;
  background-color: var(--toolbar-button-background);
  background-size: 16px 16px;
  background-position: center;
  background-repeat: no-repeat;
}

.toolbar-button:hover,
.toolbar-button:focus-visible {
  background-color: var(--toolbar-button-background-hover);
  border-color: var(--toolbar-button-border-hover);
  fill: var(--toolbar-button-foreground-hover);
}

.open .toolbar-button,
.toolbar-button:hover:active {
  background-color: var(--toolbar-button-background-active);
  border-color: var(--toolbar-button-border-active);
  color: var(--toolbar-button-foreground-active);
  fill: var(--toolbar-button-foreground-active);
}

.hover-label {
  position: absolute;
  top: 4px;
  inset-inline-start: 36px;
  line-height: 16px;
  white-space: pre; /* make sure we don't wrap */
  background-color: var(--tooltip-background);
  color: var(--tooltip-foreground);
  padding: 4px 8px;
  border: 1px solid var(--tooltip-border);
  border-radius: 2px;
  visibility: hidden;
  pointer-events: none;
  /* Put above .dropdown .dropdown-popup, which has z-index: 1000. */
  z-index: 1001;
}

/* Show the hover tooltip on non-dropdown buttons. */
.toolbar-button:not(.dropdown-toggle):hover > .hover-label,
.toolbar-button:not(.dropdown-toggle):focus-visible > .hover-label,
/* Show the hover tooltip for dropdown buttons unless its dropdown is open. */
:not(.open) > li > .dropdown-toggle:hover > .hover-label,
:not(.open) > li > .dropdown-toggle:focus-visible > .hover-label {
  visibility: visible;
}

.dropdown {
  text-align: center;
  list-style: none;
  margin: 0;
  padding: 0;
  position: relative;
}

.dropdown li {
  margin: 0;
  padding: 0;
}

/* Popup */

.dropdown .dropdown-popup {
  text-align: start;
  position: absolute;
  inset-inline-start: 40px;
  z-index: 1000;
  background-color: var(--popup-background);
  visibility: hidden;
  border-radius: 4px;
  border: 1px solid var(--popup-border);
  box-shadow: 0 0 10px 0 var(--popup-shadow);
  top: 0;
}

.open > .dropdown-popup {
  visibility: visible;
}

.dropdown-arrow {
  position: absolute;
  height: 24px;
  width: 16px;
  inset-inline-start: -16px;
  background-image: url("chrome://global/skin/reader/RM-Type-Controls-Arrow.svg");
  display: block;
  -moz-context-properties: fill, stroke;
  fill: var(--popup-background);
  stroke: var(--opaque-popup-border);
  pointer-events: none;
}

.dropdown-arrow:dir(rtl) {
  transform: scaleX(-1);
}

/* Align the style dropdown arrow (narrate does its own) */
.style-dropdown .dropdown-arrow {
  top: 7px;
}

/* Font style popup */

.radio-button {
  /* We visually hide these, but we keep them around so they can be focused
   * and changed by interacting with them via the label, or the keyboard, or
   * assistive technology.
   */
  opacity: 0;
  pointer-events: none;
  position: absolute;
}

.radiorow,
.buttonrow {
  display: flex;
  align-content: center;
  justify-content: center;
}

.content-width-value,
.font-size-value,
.line-height-value {
  box-sizing: border-box;
  width: 36px;
  height: 20px;
  line-height: 20px;
  display: flex;
  justify-content: center;
  align-content: center;
  margin: auto;
  border-radius: 10px;
  border: 1px solid var(--font-value-border);
  background-color: var(--popup-button-background);
}

.buttonrow > button {
  border: 0;
  height: 60px;
  width: 90px;
  background-color: transparent;
  background-repeat: no-repeat;
  background-position: center;
}

.buttonrow > button:enabled:hover,
.buttonrow > button:enabled:focus-visible {
  background-color: var(--popup-button-background-hover);
  color: var(--popup-button-foreground-hover);
  fill: var(--popup-button-foreground-hover);
}

.buttonrow > button:enabled:hover:active {
  background-color: var(--popup-button-background-active);
}

.radiorow:not(:last-child),
.buttonrow:not(:last-child) {
  border-bottom: 1px solid var(--popup-line);
}

body.hcm .buttonrow.line-height-buttons {
  /* On HCM the .color-scheme-buttons row is hidden, so remove the border from the row above it */
  border-bottom: none;
}

.radiorow > label {
  position: relative;
  box-sizing: border-box;
  border-radius: 2px;
  border: 2px solid var(--popup-border);
}

.radiorow > label[checked] {
  border-color: var(--selected-border);
}

/* For the hover style, we draw a line under the item by means of a
 * pseudo-element. Because these items are variable height, and
 * because their contents are variable height, position it absolutely,
 * and give it a width of 100% (the content width) + 4px for the 2 * 2px
 * border width.
 */
.radiorow > input[type=radio]:focus-visible + label::after,
.radiorow > label:hover::after {
  content: "";
  display: block;
  border-bottom: 2px solid var(--selected-border);
  width: calc(100% + 4px);
  position: absolute;
  /* to skip the 2 * 2px border + 2px spacing. */
  bottom: -6px;
  /* Match the start of the 2px border of the element: */
  inset-inline-start: -2px;
}

.font-type-buttons > label {
  height: 64px;
  width: 105px;
  /* Slightly more space between these items. */
  margin: 10px;
  /* Center the Sans-serif / Serif labels */
  text-align: center;
  background-size: 63px 39px;
  background-repeat: no-repeat;
  background-position: center 18px;
  background-color: var(--popup-button-background);
  fill: currentColor;
  -moz-context-properties: fill;
  /* This mostly matches baselines, but because of differences in font
   * baselines between serif and sans-serif, this isn't always enough. */
  line-height: 1;
  padding-top: 2px;
}

.font-type-buttons > label[checked] {
  background-color: var(--selected-background);
}

.sans-serif-button {
  font-family: Helvetica, Arial, sans-serif;
  background-image: url("chrome://global/skin/reader/RM-Sans-Serif.svg");
}

/* Tweak padding to match the baseline on mac */
:root[platform=macosx] .sans-serif-button {
  padding-top: 3px;
}

.serif-button {
  font-family: Georgia, "Times New Roman", serif;
  background-image: url("chrome://global/skin/reader/RM-Serif.svg");
}

body.hcm .color-scheme-buttons {
  /* Disallow selecting themes when HCM is on. */
  display: none;
}

.color-scheme-buttons > label {
  padding: 12px;
  height: 34px;
  font-size: 12px;
  /* Center the labels horizontally as well as vertically */
  display: inline-flex;
  align-items: center;
  justify-content: center;
  /* We want 10px between items, but there's no margin collapsing in flexbox. */
  margin: 10px 5px;
}

.color-scheme-buttons > input:first-child + label {
  margin-inline-start: 10px;
}

.color-scheme-buttons > label:last-child {
  margin-inline-end: 10px;
}

/* Toolbar icons */

.close-button {
  background-image: url("chrome://global/skin/icons/close.svg");
}

.style-button {
  background-image: url("chrome://global/skin/reader/RM-Type-Controls-24x24.svg");
}

.minus-button {
  background-size: 18px 18px;
  background-image: url("chrome://global/skin/reader/RM-Minus-24x24.svg");
}

.plus-button {
  background-size: 18px 18px;
  background-image: url("chrome://global/skin/reader/RM-Plus-24x24.svg");
}

.content-width-minus-button {
  background-size: 42px 16px;
  background-image: url("chrome://global/skin/reader/RM-Content-Width-Minus-42x16.svg");
}

.content-width-plus-button {
  background-size: 44px 16px;
  background-image: url("chrome://global/skin/reader/RM-Content-Width-Plus-44x16.svg");
}

.line-height-minus-button {
  background-size: 34px 14px;
  background-image: url("chrome://global/skin/reader/RM-Line-Height-Minus-38x14.svg");
}

.line-height-plus-button {
  background-size: 34px 24px;
  background-image: url("chrome://global/skin/reader/RM-Line-Height-Plus-38x24.svg");
}

/* Mirror the line height buttons if the article is RTL. */
.reader-controls[articledir="rtl"] .line-height-minus-button,
.reader-controls[articledir="rtl"] .line-height-plus-button {
  transform: scaleX(-1);
}

@media print {
  .toolbar {
    display: none !important;
  }
}

/* Article content */

/* Note that any class names from the original article that we want to match on
 * must be added to CLASSES_TO_PRESERVE in ReaderMode.jsm, so that
 * Readability.js doesn't strip them out */

.container {
  margin: 0 auto;
  font-size: var(--font-size);
  max-width: var(--content-width);
  line-height: var(--line-height);
}

pre {
  font-family: inherit;
}

.moz-reader-content {
  display: none;
  font-size: 1em;
}

@media print {
  .moz-reader-content p,
  .moz-reader-content code,
  .moz-reader-content pre,
  .moz-reader-content blockquote,
  .moz-reader-content ul,
  .moz-reader-content ol,
  .moz-reader-content li,
  .moz-reader-content figure,
  .moz-reader-content .wp-caption {
    margin: 0 0 10px !important;
    padding: 0 !important;
  }
}

.moz-reader-content h1,
.moz-reader-content h2,
.moz-reader-content h3 {
  font-weight: bold;
}

.moz-reader-content h1 {
  font-size: 1.6em;
  line-height: 1.25em;
}

.moz-reader-content h2 {
  font-size: 1.2em;
  line-height: 1.51em;
}

.moz-reader-content h3 {
  font-size: 1em;
  line-height: 1.66em;
}

.moz-reader-content a:link {
  text-decoration: underline;
  font-weight: normal;
}

.moz-reader-content a:link,
.moz-reader-content a:link:hover,
.moz-reader-content a:link:active {
  color: var(--link-foreground);
}

.moz-reader-content a:visited {
  color: var(--visited-link-foreground);
}

.moz-reader-content * {
  max-width: 100%;
  height: auto;
}

.moz-reader-content p,
.moz-reader-content p,
.moz-reader-content code,
.moz-reader-content pre,
.moz-reader-content blockquote,
.moz-reader-content ul,
.moz-reader-content ol,
.moz-reader-content li,
.moz-reader-content figure,
.moz-reader-content .wp-caption {
  margin: -10px -10px 20px;
  padding: 10px;
  border-radius: 5px;
}

.moz-reader-content li {
  margin-bottom: 0;
}

.moz-reader-content li > ul,
.moz-reader-content li > ol {
  margin-bottom: -10px;
}

.moz-reader-content p > img:only-child,
.moz-reader-content p > a:only-child > img:only-child,
.moz-reader-content .wp-caption img,
.moz-reader-content figure img {
  display: block;
}

.moz-reader-content img[moz-reader-center] {
  margin-inline: auto;
}

.moz-reader-content .caption,
.moz-reader-content .wp-caption-text
.moz-reader-content figcaption {
  font-size: 0.9em;
  line-height: 1.48em;
  font-style: italic;
}

.moz-reader-content pre {
  white-space: pre-wrap;
}

.moz-reader-content blockquote {
  padding: 0;
  padding-inline-start: 16px;
}

.moz-reader-content ul,
.moz-reader-content ol {
  padding: 0;
}

.moz-reader-content ul {
  padding-inline-start: 30px;
  list-style: disc;
}

.moz-reader-content ol {
  padding-inline-start: 30px;
}

table,
th,
td {
  border: 1px solid currentColor;
  border-collapse: collapse;
  padding: 6px;
  vertical-align: top;
}

table {
  margin: 5px;
}

/* Visually hide (but don't display: none) screen reader elements */
.moz-reader-content .visually-hidden,
.moz-reader-content .visuallyhidden,
.moz-reader-content .sr-only {
  display: inline-block;
  width: 1px;
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  border-width: 0;
}

/* Hide elements with common "hidden" class names */
.moz-reader-content .hidden,
.moz-reader-content .invisible {
  display: none;
}

/* Enforce wordpress and similar emoji/smileys aren't sized to be full-width,
 * see bug 1399616 for context. */
.moz-reader-content img.wp-smiley,
.moz-reader-content img.emoji {
  display: inline-block;
  border-width: 0;
  /* height: auto is implied from '.moz-reader-content *' rule. */
  width: 1em;
  margin: 0 .07em;
  padding: 0;
}

.reader-show-element {
  display: initial;
}

/* Provide extra spacing for images that may be aided with accompanying element such as <figcaption> */
.moz-reader-block-img:not(:last-child) {
  margin-block-end: 12px;
}

.moz-reader-wide-table {
  overflow-x: auto;
  display: block;
}

pre code {
  background-color: var(--main-background);
  border: 1px solid var(--font-color);
  display: block;
  overflow: auto;
}`;
	}

	function isAncestor(element, otherElement) {
		return otherElement.parentElement && (element == otherElement.parentElement || isAncestor(element, otherElement.parentElement));
	}

	async function getDataURI(blob) {
		if (globalThis.FileReader) {
			const reader = new globalThis.FileReader();
			reader.readAsDataURL(blob);
			return new Promise((resolve, reject) => {
				reader.addEventListener("load", () => resolve(reader.result), false);
				reader.addEventListener("error", reject, false);
			});
		} else {
			const bytes = new Uint8Array(await blob.arrayBuffer());
			let content = "";
			for (let offset = 0; offset < bytes.length; offset += 8192) {
				content += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
			}
			return "data:" + (blob.type || "application/octet-stream") + ";base64," + btoa(content);
		}
	}

	function detectSavedPage(document) {
		const firstDocumentChild = document.documentElement.firstChild;
		return firstDocumentChild.nodeType == Node.COMMENT_NODE &&
			(firstDocumentChild.textContent.includes(COMMENT_HEADER) || firstDocumentChild.textContent.includes(COMMENT_HEADER_LEGACY));
	}

})();